#!/usr/bin/env python3
# build_core_kr.py — 한국 종목을 Pattern Match 형식으로 변환.
# 머플 저장분(/root/krx-moneyflow/data/stocks/{code}.json) 재활용 (중복 수집 없음).
# closes(매칭용) + ohlcv(거래량/대금/고저, 고도화 레이어용) 함께 저장.
# 시장 분리: data/closes/kr/{code}.json
# 실행: python3 pipeline/build_core_kr.py [--src DIR] [--out DIR] [--universe core|extended|both]
import json, os, sys, glob, datetime, argparse

ap = argparse.ArgumentParser()
ap.add_argument("--src", default="/root/krx-moneyflow/data/stocks")
ap.add_argument("--out", default="/var/www/f29-pattern-lab/data/closes/kr")
ap.add_argument("--universe", default="both", choices=["core","extended","both"])
ap.add_argument("--keep", type=int, default=90)
ap.add_argument("--min-bars", type=int, default=60)
ap.add_argument("--prune", action="store_true",
                help="유니버스 이탈(고아) 산출물을 백업 후 삭제. 미지정 시 검출·보고만.")
a = ap.parse_args()

HERE = os.path.dirname(os.path.abspath(__file__))
today = datetime.date.today().isoformat()

def load_uni(name):
    try:
        return json.load(open(os.path.join(HERE, f"universe.kr.{name}.json")))["tickers"]
    except Exception as e:
        print(f"universe.kr.{name}.json 로드 실패: {e}"); return []

codes = []
if a.universe in ("core","both"):     codes += load_uni("core")
if a.universe in ("extended","both"): codes += load_uni("extended")
codes = list(dict.fromkeys(codes))  # 중복 제거, 순서 유지
if not codes:
    print("변환할 종목 없음"); sys.exit(1)

os.makedirs(a.out, exist_ok=True)
ok = skip = 0; skipped = []
for c in codes:
    src = os.path.join(a.src, c + ".json")
    if not os.path.exists(src):
        skip += 1; skipped.append(f"{c}:파일없음"); continue
    try:
        d = json.load(open(src))
        bars = d.get("bars", [])
        if len(bars) < a.min_bars:
            skip += 1; skipped.append(f"{c}:{len(bars)}봉"); continue
        bars = bars[-a.keep:]                          # 최근 keep개
        closes = [b["close"] for b in bars]
        if any(x is None or x == 0 for x in closes):
            skip += 1; skipped.append(f"{c}:결측"); continue
        # YYYYMMDD → YYYY-MM-DD (미국과 통일, 엔진 ymd() 파서 호환)
        def fmt(ds):
            ds = str(ds)
            return ds[:4] + "-" + ds[4:6] + "-" + ds[6:8] if len(ds) == 8 and ds.isdigit() else ds
        dates = [fmt(b["date"]) for b in bars]         # YYYY-MM-DD, 오름차순
        # 고도화 레이어용 OHLCV (거래량·대금·고저 보존)
        ohlcv = [{"date": fmt(b["date"]), "open": b.get("open"), "high": b.get("high"),
                  "low": b.get("low"), "close": b["close"], "volume": b.get("volume"),
                  "tradingValue": b.get("tradingValue")} for b in bars]
        out = {
            "ticker": c, "name": d.get("name", ""), "market": "kr",
            "marketCategory": d.get("marketCategory", ""),
            "updated": today, "last_bar": dates[-1] if dates else None,
            "n": len(closes), "source": "krx-moneyflow",
            "dates": dates, "closes": closes, "ohlcv": ohlcv,
        }
        fp = os.path.join(a.out, c + ".json")
        json.dump(out, open(fp, "w"), ensure_ascii=False)
        os.chmod(fp, 0o644)                            # nginx 읽기
        ok += 1
    except Exception as e:
        skip += 1; skipped.append(f"{c}:{type(e).__name__}")

print(f"[{today}] 한국 변환: 성공 {ok} / 스킵 {skip} → {a.out}")
if skipped:
    print("스킵:", ", ".join(skipped[:20]) + (" ..." if len(skipped) > 20 else ""))

# ── 고아 파일 검출 (유니버스 이탈분) ────────────────────────────────
# 유니버스를 개편하면 이전 목록의 산출물이 남는다. 이 파일은 크론 갱신 대상이 아니라
# 시간이 갈수록 낡고, match.html은 6자리 코드를 무조건 kr/로 라우팅하므로 사용자에게 도달한다.
# 낡은 판정보다 "준비되지 않음" 안내가 정직하다는 원칙(Sky 확정 2026-07-20)에 따라 정리 대상.
# ★기본은 보고만. 삭제는 --prune 명시 시에만 — 무단 삭제 방지.★
try:
    present = {f[:-5] for f in os.listdir(a.out) if f.endswith(".json")}
    orphans = sorted(present - set(codes))          # codes는 list — 집합 변환 필수
    if orphans:
        print(f"고아 파일 {len(orphans)}건 (유니버스 이탈):", ", ".join(orphans[:20]) +
              (" ..." if len(orphans) > 20 else ""))
        if a.prune:
            bk = os.path.join("/root/f29-backups", "kr-orphans-" +
                              datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"))
            os.makedirs(bk, exist_ok=True)
            import shutil
            for c in orphans:
                src = os.path.join(a.out, c + ".json")
                shutil.copy2(src, os.path.join(bk, c + ".json"))   # 백업 후 삭제
                os.remove(src)
            print(f"  → 삭제 완료. 백업: {bk}")
        else:
            print("  → 삭제하려면 --prune 지정 (백업 후 삭제)")
    else:
        print("고아 파일 없음 — 유니버스와 산출물 일치")
except Exception as e:
    print("고아 검출 실패(무시):", e)
