#!/usr/bin/env node
/* record_pattern_history.js — 코어 종목 패턴 판정 안정도(Pattern Stability) 로그.
   ★이것은 예측 성과표가 아니라 엔진 판정 품질 로그다.★
   매일 각 코어 종목이 어떤 패턴으로 "분류"됐는지 기록 → 나중에 "형태 일관성" 지표로 사용.
   방향 적중률/신뢰도가 아님. 저장은 웹 비공개 /root/f29-pattern-lab/history/.
   실행: node tools/record_pattern_history.js [--closes DIR] [--out DIR] */
const fs=require("fs"), path=require("path"), crypto=require("crypto");
global.window=global;
require(path.join(__dirname,"..","data","patterns","patterns-bundle.js"));
const ME=require(path.join(__dirname,"..","js","match-engine.js"));
const byId=window.F29.PATTERN_BUNDLE;

function arg(f,d){const i=process.argv.indexOf(f);return i>=0?process.argv[i+1]:d;}
// 서버 기본 경로. --closes/--out 로 오버라이드 가능.
const CLOSES=arg("--closes","/var/www/f29-pattern-lab/data/closes");
const OUTDIR=arg("--out","/root/f29-pattern-lab/history/pattern_judgments");
// --universe: 콤마 구분 다중 경로 지원. 미지정 시 기본 = core + us_pages(있으면).
// ★단일 날짜 파일 원자 교체 방식이므로 유니버스별 재실행 금지 — 한 번에 전부 읽어야 덮어쓰기가 없다.
const PDIR=path.join(__dirname,"..","pipeline");
const DEFAULT_UNI=[path.join(PDIR,"universe.core.json"), path.join(PDIR,"universe.us_pages.json")]
  .filter(p=>fs.existsSync(p));
const UNI=arg("--universe",null);
const UNI_LIST=UNI?UNI.split(",").map(s=>s.trim()).filter(Boolean):DEFAULT_UNI;
const MIN_BARS=parseInt(arg("--min-bars","15"),10);   // 판정 최소 봉수 (기존 동작 유지값)

const ENGINE_VERSION="match-v1";
const LIB_VERSION=new Date().toISOString().slice(0,10); // 패턴 라이브러리 스냅샷일 (변경시 갱신)
const today=new Date().toISOString().slice(0,10);

let coreSet=new Set();
const loaded=[];
UNI_LIST.forEach(p=>{
  try{
    const t=JSON.parse(fs.readFileSync(p,"utf8")).tickers||[];
    t.forEach(x=>coreSet.add(x));                       // Set 병합 = 중복 자동 제거
    loaded.push(path.basename(p)+"("+t.length+")");
  }catch(e){ console.error("universe 로드 실패:",p,e.message); }
});
if(coreSet.size===0){ console.error("유니버스 비어있음 — 경로 확인:",UNI_LIST.join(",")); process.exit(1); }

function round(x){ return Math.round(x*100)/100; }

const rows=[];
let ok=0, skip=0;
[...coreSet].forEach(t=>{
  const fp=path.join(CLOSES, t+".json");
  let d;
  try{ d=JSON.parse(fs.readFileSync(fp,"utf8")); }
  catch(e){ skip++; return; }                         // 파일 없으면 스킵 (조용히)
  if(!Array.isArray(d.closes)||d.closes.length<MIN_BARS){ skip++; return; }
  const top=ME.matchFlow(d.closes, byId, 3);
  const feat=ME.seriesVec(d.closes);
  const hash=crypto.createHash("sha256").update(JSON.stringify(d.closes)).digest("hex").slice(0,16);
  const rec={
    date: today,
    ticker: t,
    name: d.name||undefined,        // 한국 종목명 (있으면)
    data_last_date: d.last_bar||(d.dates?d.dates[d.dates.length-1]:null),
    bars: d.closes.length,
    engine_version: ENGINE_VERSION,
    pattern_library_version: LIB_VERSION,
    top1: top[0]?{pattern_id:top[0].id, pattern_title:top[0].title, score:top[0].score}:null,
    top2: top[1]?{pattern_id:top[1].id, pattern_title:top[1].title, score:top[1].score}:null,
    top3: top[2]?[{pattern_id:top[2].id, pattern_title:top[2].title, score:top[2].score}]:[],
    gap12: (top[0]&&top[1])?top[0].score-top[1].score:null,
    structure: top[0]&&top[0].structure?top[0].structure.status:null,  // near/watch/weak/limited/null
    feature: {net:round(feat[0]),osc:round(feat[1]),conv:round(feat[2]),arc:round(feat[3])},
    input_hash: hash
  };
  rows.push(JSON.stringify(rec));
  ok++;
});

if(rows.length===0){ console.error("기록할 종목 없음 (closes 데이터 확인)"); process.exit(1); }

fs.mkdirSync(OUTDIR,{recursive:true});
const finalPath=path.join(OUTDIR, today+".jsonl");
const tmpPath=finalPath+".tmp";
// 원자적 쓰기: tmp에 전체 기록 → 검증 → rename (같은날 재실행 시 덮어씀 = 최신 데이터 우선)
fs.writeFileSync(tmpPath, rows.join("\n")+"\n");
// 검증: 줄 수 == 기록 수
const check=fs.readFileSync(tmpPath,"utf8").trim().split("\n").length;
if(check!==rows.length){ console.error("검증 실패: 줄 수 불일치"); process.exit(1); }
fs.renameSync(tmpPath, finalPath);
try{ fs.chmodSync(finalPath, 0o600); }catch(e){}  // 내부 전용

console.log(`[${today}] 판정 안정도 로그 기록: ${ok}종목 (스킵 ${skip}) → ${finalPath}`);
console.log(`  유니버스: ${loaded.join(" + ")} = ${coreSet.size}종목 · 최소봉수 ${MIN_BARS}`);
