#!/usr/bin/env node
/* F29 Pattern Match — pipeline/cluster_report.js  [반자동 감시 장치: 탐지·리포트까지만]
   저커버(score<65) 종목을 형태로 클러스터링해 "사람 검토가 필요한 후보"를 리포트한다.
   ★패턴 JSON/퀴즈/해설 자동 생성 금지. 자동 결론은 PASS/WATCH/REVIEW 라벨까지만.★
   실행: node pipeline/cluster_report.js [--set core40|holdout50|combined90] [--out reports]
   대상: 서버 크론 수집 universe 데이터만 (사용자 붙여넣기 제외). */
const fs=require("fs"), path=require("path");
const ME=require("../js/match-engine.js");
const PDIR=path.join(__dirname,"..","data","patterns");
const CDIR=path.join(__dirname,"..","data","closes");
function arg(f,d){const i=process.argv.indexOf(f);return i>=0?process.argv[i+1]:d;}
const SET=arg("--set","combined90"), OUT=arg("--out",null);

// 기준 잠금 (Sky 원칙: 5개는 필요조건, compactness·쏠림이 충분조건)
const LOW=65, MISS=45, LOWER=60;
const MIN_CLUSTER=5, DIST=0.6;
const COMPACT_MAX=0.35;      // 클러스터 응집도: 중심까지 평균거리 이하여야 "조밀"
const CONCENTRATION=0.70;    // top1 패턴 쏠림: 상위 1~2개 패턴이 이 비율 이상 차지
const REVIEW_AVG=62;         // REVIEW 후보 평균 score 상한

function loadUni(f){try{return new Set(JSON.parse(fs.readFileSync(path.join(__dirname,f),"utf8")).tickers);}catch(e){return new Set();}}
const core=loadUni("universe.core.json"), hold=loadUni("universe.holdout.json");
const krCore=loadUni("universe.kr.core.json");
function inSet(t){ if(SET==="core40")return core.has(t); if(SET==="holdout50")return hold.has(t); if(SET==="kr50")return krCore.has(t); return core.has(t)||hold.has(t); }
// 한국 세트면 kr/ 폴더에서 읽음 (시장 분리)
const CLOSES_DIR = SET==="kr50" ? path.join(CDIR,"kr") : CDIR;

const byId={};
fs.readdirSync(PDIR).filter(f=>f.endsWith(".json")).forEach(f=>{const p=JSON.parse(fs.readFileSync(path.join(PDIR,f),"utf8"));byId[p.id]=p;});

// 전체 종목 스코어링 (커버리지용) + 저커버 수집
const all=[], low=[];
fs.readdirSync(CLOSES_DIR).filter(f=>f.endsWith(".json")).forEach(f=>{
  let d;try{d=JSON.parse(fs.readFileSync(path.join(CLOSES_DIR,f),"utf8"));}catch(e){return;}
  if(d.ticker==="DEMO"||!inSet(d.ticker)||!Array.isArray(d.closes)||d.closes.length<15)return;
  const feat=ME.seriesVec(d.closes), top=ME.matchFlow(d.closes,byId,1)[0];
  all.push({t:d.ticker, s:top.score, best:top.title});
  if(top.score<LOW) low.push({t:d.ticker, s:top.score, best:top.title, f:feat});
});

// 그리디 클러스터링 (특성 L2 거리)
function dist(a,b){let s=0;for(let i=0;i<4;i++)s+=(a[i]-b[i])**2;return Math.sqrt(s);}
const clusters=[];
low.forEach(pt=>{
  let best=null,bd=DIST;
  clusters.forEach(c=>{const dd=dist(pt.f,c.centroid);if(dd<bd){bd=dd;best=c;}});
  if(best){best.members.push(pt);best.centroid=best.centroid.map((v,i)=>(v*(best.members.length-1)+pt.f[i])/best.members.length);}
  else clusters.push({centroid:pt.f.slice(),members:[pt]});
});
clusters.sort((a,b)=>b.members.length-a.members.length);

function hint(c){
  const [net,,conv,arc]=c;
  // arc: +1=산형(중간봉우리,상승후하락) / -1=골형(중간저점,하락후반등=둥근바닥)
  if(net<-0.35&&arc<-0.3) return "하락+골형 → 둥근 바닥 후보 (하락 후 저점 다지기)";
  if(net<-0.35&&arc>0.3) return "봉우리 후 강한 하락 → 천장형 하락 (더블탑/헤드앤숄더 강한 하락 버전일 수 있음)";
  if(net>0.35&&arc>0.4) return "상승+산형 → 둥근 고점 유형 (이미 존재)";
  if(conv<-0.35) return "발산 → 확산형 유형 (이미 존재)";
  if(net>0.55&&Math.abs(arc)<0.25&&Math.abs(conv)<0.25) return "강한 추세+저진동 → 상승 플래그/채널 후보";
  if(net>0.35&&conv>0.35&&Math.abs(arc)<0.3) return "상승+수렴 → 상승 쐐기 후보";
  return "혼합형 — 명확한 단일 방향 아님";
}
// 응집도: 중심까지 평균거리 (작을수록 조밀)
function compactness(c){ if(c.members.length<2) return 0; return c.members.reduce((s,m)=>s+dist(m.f,c.centroid),0)/c.members.length; }
// 라벨 점유율 2종 (명칭 정확히 분리 — 과거 top2 합산을 'top1 쏠림'으로 오표기한 결함 수정)
//   top1Ratio = 최다 단일 패턴 비중 (한 형태로 뭉쳐 있는가)
//   top2Ratio = 상위 2개 패턴 합산 비중 (게이트 기준값 — 기존 동작 유지)
function concentration(c){
  const cnt={}; c.members.forEach(m=>cnt[m.best]=(cnt[m.best]||0)+1);
  const sorted=Object.values(cnt).sort((a,b)=>b-a);
  const n=c.members.length;
  const top1=sorted[0]||0;
  const top2=sorted.slice(0,2).reduce((a,b)=>a+b,0);
  return {top1Ratio:top1/n, top2Ratio:top2/n, ratio:top2/n, labels:sorted.length, dist:cnt};
}
// 클러스터 판정 (5개는 필요조건일 뿐)
function verdictOf(c){
  const n=c.members.length, avg=c.members.reduce((s,m)=>s+m.s,0)/n;
  const comp=compactness(c), con=concentration(c);
  if(n>=MIN_CLUSTER && comp<=COMPACT_MAX && avg<REVIEW_AVG && con.ratio>=CONCENTRATION) return "REVIEW";
  if(n>=MIN_CLUSTER) return "WATCH";        // 5개지만 조밀/쏠림 조건 미달
  if(n>=3) return "WATCH";                   // 3~4개 관찰 지속
  return "-";
}

// 커버리지 집계
const miss=all.filter(x=>x.s<MISS).length, mid=all.filter(x=>x.s>=MISS&&x.s<LOW).length, good=all.filter(x=>x.s>=LOW).length;
const top1cnt={}; all.forEach(x=>top1cnt[x.best]=(top1cnt[x.best]||0)+1);
const top1sorted=Object.entries(top1cnt).sort((a,b)=>b[1]-a[1]);

const L=[];
L.push(`# F29 저커버 클러스터 감시 리포트 (내부 판단용 · 사용자 비공개)`);
L.push(`생성: ${new Date().toISOString().slice(0,10)} · dataset: ${SET} · 분석 ${all.length}종목`);
L.push(`※ 자동 패턴 추가 대상이 아닙니다. 사람 검토가 필요한 후보까지만 표시합니다.`);
L.push("");
L.push(`## 1. 전체 커버리지`);
L.push(`못잡음(<${MISS}): ${miss} · 보통(${MISS}~${LOW-1}): ${mid} · 잘잡음(>=${LOW}): ${good}`);
L.push("");
L.push(`## 2. top1 패턴 쏠림`);
top1sorted.slice(0,6).forEach(([p,n])=>L.push(`- ${p}: ${n}종목`));
L.push("");
L.push(`## 3. score<${LOW} 저커버 목록`);
low.slice().sort((a,b)=>a.s-b.s).forEach(m=>L.push(`- ${m.t} (${m.s}) → top1: ${m.best} · [${m.f.map(x=>Math.round(x*100)/100).join(", ")}]`));
if(low.length===0) L.push("- (없음)");
L.push("");
L.push(`## 4. 저커버 클러스터 후보`);
let hasReview=false, hasWatch=false;
clusters.forEach((c,i)=>{
  const v=verdictOf(c); if(v==="REVIEW")hasReview=true; if(v==="WATCH")hasWatch=true;
  const avg=Math.round(c.members.reduce((s,m)=>s+m.s,0)/c.members.length*10)/10;
  const comp=Math.round(compactness(c)*100)/100, con=concentration(c);
  L.push(`### 클러스터 ${i+1} — ${c.members.length}종목 · 판정 ${v}`);
  L.push(`평균 score ${avg} · 응집도 ${comp}(<=${COMPACT_MAX} 조밀) · 최다단일패턴 ${Math.round(con.top1Ratio*100)}% · 상위2합산 ${Math.round(con.top2Ratio*100)}%(게이트 기준 ${Math.round(CONCENTRATION*100)}%)`);
  L.push(`특성중심 [net,osc,conv,arc]=[${c.centroid.map(x=>Math.round(x*100)/100).join(", ")}] · ${hint(c.centroid)}`);
  L.push(`종목: ${c.members.map(m=>m.t+"("+m.s+")").join(", ")}`);
  L.push(`기존 top1 분포: ${Object.entries(con.dist).map(([p,n])=>p+"×"+n).join(", ")}`);
  L.push("");
});
if(clusters.length===0) L.push("- 저커버 종목 없음 — 라이브러리 충분\n");

// 최종 판정 (PASS/WATCH/REVIEW 만)
const verdict = hasReview ? "REVIEW" : (hasWatch ? "WATCH" : "PASS");
const msg = {
  PASS:  "PASS — 신규 패턴 후보 없음. 조치 불필요.",
  WATCH: "WATCH — 저커버 클러스터 관찰 지속. 5개 도달·조밀·쏠림 조건 완성 시 REVIEW로 승격.",
  REVIEW:"REVIEW — 사람 검토가 필요한 저커버 클러스터 발견. Sky가 실제 형태·시그니처를 확인 후 패턴 설계 여부를 판정. (자동 생성·배포 금지)"
}[verdict];
L.push(`## 5. 판정: ${verdict}`);
L.push(msg);

const report=L.join("\n");
console.log(report);
// ── 시간 지속성 계측 (감리 요구 게이트 ①의 데이터 기반) ──────────────
// 클러스터 구성을 기계판독 스냅샷으로 남기고, 직전 스냅샷과 Jaccard 중복률을 측정한다.
// ★현 차수는 계측·기록만. REVIEW 게이트 조건으로는 아직 사용하지 않는다(게이트 변경 = Sky 판정 사항).★
const SNAP_NAME="cluster_snapshot_"+SET+".json";
function jaccard(a,b){ const A=new Set(a),B=new Set(b); let inter=0; A.forEach(x=>{if(B.has(x))inter++;});
  const uni=A.size+B.size-inter; return uni?inter/uni:0; }
if(OUT){
  const dir=path.isAbsolute(OUT)?OUT:path.join(__dirname,"..",OUT); fs.mkdirSync(dir,{recursive:true});
  const snapPath=path.join(dir,SNAP_NAME);
  const cur={date:new Date().toISOString().slice(0,10), set:SET,
    clusters:clusters.map(c=>({members:c.members.map(m=>m.t).sort(), centroid:c.centroid,
      verdict:verdictOf(c), avg:Math.round(c.members.reduce((s,m)=>s+m.s,0)/c.members.length*10)/10}))};
  let prev=null; try{ prev=JSON.parse(fs.readFileSync(snapPath,"utf8")); }catch(e){}
  const P=[];
  P.push("");
  P.push("## 6. 시간 지속성 (계측 기록 — 게이트 미적용)");
  if(!prev){ P.push("- 직전 스냅샷 없음. 이번 실행분을 기준선으로 저장합니다."); }
  else{
    P.push(`- 직전 스냅샷: ${prev.date} (클러스터 ${prev.clusters.length}개)`);
    cur.clusters.forEach((c,i)=>{
      let best=0, bi=-1;
      (prev.clusters||[]).forEach((p,j)=>{ const s=jaccard(c.members,p.members); if(s>best){best=s;bi=j;} });
      const keep=best>=0.6?"유지":"변동";
      P.push(`- 클러스터 ${i+1}(${c.members.length}종): 직전 대비 최대 Jaccard ${Math.round(best*100)/100}` +
             (bi>=0?` (직전 클러스터 ${bi+1})`:"") + ` — ${keep} (기준 0.6)`);
    });
  }
  P.push("※ 3회 연속 유지 + 기존 패턴 중심 분리도 + 한 문장 형태 설명이 갖춰져야 신규 패턴 검토 대상입니다.");
  const extra=P.join("\n");
  console.log(extra);
  fs.writeFileSync(snapPath, JSON.stringify(cur,null,2));
  const fp=path.join(dir,"cluster_"+cur.date+".md");
  fs.writeFileSync(fp, report+"\n"+extra); console.log("\n리포트 저장:",fp,"\n스냅샷 저장:",snapPath);
}
