# F29 Pattern Match — 데이터 파이프라인 (STEP 5)

Pattern Match 에 실시간 티커 종가를 공급. 정적+크론, 새 pm2 프로세스 불필요.

## 데이터 소스 = Databento (MF와 동일)
무료 소스(stooq/yahoo)는 데이터센터 IP가 차단돼 VPS에서 불가. MF가 쓰는 Databento 재사용.
- SDK: `databento` (Python), venv = `/root/moneyflow/venv`
- 키: 환경변수 `DATABENTO_API_KEY` (SDK 자동 사용)
- dataset=`DBEQ.BASIC`, schema=`ohlcv-1d`
- ※ DBEQ.BASIC은 venue별 일봉 → ts_event+symbol 거래량가중 통합(MF fetch_daily.py 로직 재사용)

## 구조
```
티커 입력 → match.html 이 /lab/data/closes/<TICKER>.json fetch
  → 있으면 실제 종가로 매칭 / 없으면 404 안내(+nginx 로그에 수요 기록)
크론1(매일) build_core.py    → 코어 유니버스 종가 → data/closes/*.json
크론2(주1)  analyze_demand.js → 로그 404 집계 → 승격 후보(사람 확인)
```

## 최초 셋업 (VPS)
```bash
cd /var/www/f29-pattern-lab
PY=~/moneyflow/venv/bin/python   # MF venv (databento SDK 있음)

# 0) 키 확인
echo "key: ${DATABENTO_API_KEY:+SET}"
#   비어있으면 pm2 moneyflow env에서 찾아 export:
#   pm2 env 1 | grep -i databento     → export DATABENTO_API_KEY=db-xxxx

# 1) 단일 티커 소스 확인
$PY -c "import databento as db; d=db.Historical().timeseries.get_range(dataset='DBEQ.BASIC',symbols=['NVDA'],schema='ohlcv-1d',start='2026-06-15',end='2026-07-04'); print('rows',d.to_df().shape)"

# 2) 코어 유니버스 전체 빌드 (40종목, 배치 요청)
sudo -E $PY pipeline/build_core.py --days 90 --keep 60
#   sudo -E = 환경변수(키) 유지. 출력 data/closes/*.json

# 3) 확인
curl -s https://f29.io/lab/data/closes/NVDA.json | head -c 160; echo
```
그다음 match.html 에서 NVDA 입력 → 실제 종가로 매칭.

## 크론 (미국장 마감 후 = UTC 22:10 평일)
```
10 22 * * 1-5  cd /var/www/f29-pattern-lab && DATABENTO_API_KEY=db-xxxx ~/moneyflow/venv/bin/python pipeline/build_core.py --days 90 --keep 60 >> /var/log/f29-patternmatch.log 2>&1
0 3 * * 1      cd /var/www/f29-pattern-lab && /usr/bin/node pipeline/analyze_demand.js /var/log/nginx/access.log --min 3 >> /var/log/f29-patternmatch.log 2>&1
```
※ 크론엔 셸 env가 없으니 키를 명시(또는 EnvironmentFile). crontab 편집은 직접/heredoc(sed 금지).

## 승격 워크플로
analyze_demand.js → demand.json + 후보 → universe.core.json 에 추가 → build_core.py 재실행.
자동추가 아님(사람 게이트). 30일 조회 0 비코어는 유니버스에 없으면 애초에 안 만듦.

## 파일
- build_core.py    — 프로덕션(Databento). MF venv로 실행.
- build_core.js    — 오프라인 테스트용(mock). 실소스는 py 사용.
- fetchers.js      — Node용 어댑터(mock/stooq). 참고용.
- analyze_demand.js— 수요 집계(Node, 소스 무관).
- universe.core.json — 코어 40종목.

## Holdout 검증 (일반화 확인)
core40에서 찾은 갭을 core40으로 개선 확인 → 순환 리스크. holdout50(비겹침 인기종목)으로 일반화 검증.
```bash
# H2: holdout 50종목 종가 확보 (같은 data/closes 에 추가)
export DATABENTO_API_KEY=db-XXXX
~/moneyflow/venv/bin/python pipeline/build_core.py --universe pipeline/universe.holdout.json --out /var/www/f29-pattern-lab/data/closes --days 90 --keep 60 --force
# H4: 세 세트 각각 분석
node pipeline/analyze_shapes.js --set holdout50    # ★ 핵심: 일반화 검증
node pipeline/analyze_shapes.js --set core40       # 회귀(변화 없어야)
node pipeline/analyze_shapes.js --set combined90   # 전체
```
판정선(자동 출력): holdout50 = 못잡음 <=2 · 보통 <=8 · 잘잡음 >=40 · 단일패턴 <=18.
통과 → 라이브러리 잠금, 퀴즈로. 미달 → [3] 목록의 같은-형태 클러스터만 2차 확장.
