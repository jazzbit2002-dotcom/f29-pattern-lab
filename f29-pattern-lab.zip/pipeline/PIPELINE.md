# F29 Pattern Match — 데이터 파이프라인 (STEP 5)

Pattern Match 에 실시간 티커 종가를 공급. 정적+크론, 새 pm2 프로세스 불필요.

## 데이터 소스 = Databento (MF와 동일)
무료 소스(stooq/yahoo)는 데이터센터 IP가 차단돼 VPS에서 불가. MF가 쓰는 Databento 재사용.
- SDK: `databento` (Python), venv = `/root/moneyflow/venv`
- 키: 환경변수 `DATABENTO_API_KEY` (SDK 자동 사용)
- dataset=`DBEQ.BASIC`, schema=`ohlcv-1d`
- ※ DBEQ.BASIC은 venue별 일봉 → ts_event+symbol 거래량가중 통합(MF fetch_daily.py 로직 재사용)

## 구조
```
티커 입력 → match.html 이 /lab/data/closes/<TICKER>.json fetch
  → 있으면 실제 종가로 매칭 / 없으면 404 안내(+nginx 로그에 수요 기록)
크론1(매일) build_core.py    → 코어 유니버스 종가 → data/closes/*.json
크론2(주1)  analyze_demand.js → 로그 404 집계 → 승격 후보(사람 확인)
```

## 최초 셋업 (VPS)
```bash
cd /var/www/f29-pattern-lab
PY=~/moneyflow/venv/bin/python   # MF venv (databento SDK 있음)

# 0) 키 확인
echo "key: ${DATABENTO_API_KEY:+SET}"
#   비어있으면 pm2 moneyflow env에서 찾아 export:
#   pm2 env 1 | grep -i databento     → export DATABENTO_API_KEY=db-xxxx

# 1) 단일 티커 소스 확인
$PY -c "import databento as db; d=db.Historical().timeseries.get_range(dataset='DBEQ.BASIC',symbols=['NVDA'],schema='ohlcv-1d',start='2026-06-15',end='2026-07-04'); print('rows',d.to_df().shape)"

# 2) 코어 유니버스 전체 빌드 (40종목, 배치 요청)
sudo -E $PY pipeline/build_core.py --days 90 --keep 60
#   sudo -E = 환경변수(키) 유지. 출력 data/closes/*.json

# 3) 확인
curl -s https://f29.io/lab/data/closes/NVDA.json | head -c 160; echo
```
그다음 match.html 에서 NVDA 입력 → 실제 종가로 매칭.

## 크론 (미국장 마감 후 = UTC 22:10 평일)
```
10 22 * * 1-5  cd /var/www/f29-pattern-lab && DATABENTO_API_KEY=db-xxxx ~/moneyflow/venv/bin/python pipeline/build_core.py --days 90 --keep 60 >> /var/log/f29-patternmatch.log 2>&1
0 3 * * 1      cd /var/www/f29-pattern-lab && /usr/bin/node pipeline/analyze_demand.js /var/log/nginx/access.log --min 3 >> /var/log/f29-patternmatch.log 2>&1
```
※ 크론엔 셸 env가 없으니 키를 명시(또는 EnvironmentFile). crontab 편집은 직접/heredoc(sed 금지).

## 승격 워크플로
analyze_demand.js → demand.json + 후보 → universe.core.json 에 추가 → build_core.py 재실행.
자동추가 아님(사람 게이트). 30일 조회 0 비코어는 유니버스에 없으면 애초에 안 만듦.

## 파일
- build_core.py    — 프로덕션(Databento). MF venv로 실행.
- build_core.js    — 오프라인 테스트용(mock). 실소스는 py 사용.
- fetchers.js      — Node용 어댑터(mock/stooq). 참고용.
- analyze_demand.js— 수요 집계(Node, 소스 무관).
- universe.core.json — 코어 40종목.

## Holdout 검증 (일반화 확인)
core40에서 찾은 갭을 core40으로 개선 확인 → 순환 리스크. holdout50(비겹침 인기종목)으로 일반화 검증.
```bash
# H2: holdout 50종목 종가 확보 (같은 data/closes 에 추가)
export DATABENTO_API_KEY=db-XXXX
~/moneyflow/venv/bin/python pipeline/build_core.py --universe pipeline/universe.holdout.json --out /var/www/f29-pattern-lab/data/closes --days 90 --keep 60 --force
# H4: 세 세트 각각 분석
node pipeline/analyze_shapes.js --set holdout50    # ★ 핵심: 일반화 검증
node pipeline/analyze_shapes.js --set core40       # 회귀(변화 없어야)
node pipeline/analyze_shapes.js --set combined90   # 전체
```
판정선(자동 출력): holdout50 = 못잡음 <=2 · 보통 <=8 · 잘잡음 >=40 · 단일패턴 <=18.
통과 → 라이브러리 잠금, 퀴즈로. 미달 → [3] 목록의 같은-형태 클러스터만 2차 확장.

## 반자동 패턴 후보 탐지 (탐지 자동 + 사람 승인)
저커버 종목을 형태로 클러스터링해 "패턴 추가 후보"를 리포트. ★자동 생성 안 함★ — Sky가 판정.
```bash
node pipeline/cluster_report.js --set combined90 --out reports   # reports/cluster_YYYYMMDD.md 생성
```
트리거: 같은 형태 클러스터 5개 이상 + score<65 → "검토 대상" 플래그. 미달이면 "보류".
(선택) 주간 크론:
```
0 8 * * 1 cd /var/www/f29-pattern-lab && node pipeline/cluster_report.js --set combined90 --out reports >> /var/log/f29-cluster.log 2>&1
```
흐름: GA4 인기종목 → universe 추가 → 크론 갱신 → 주간 cluster_report → Sky 판정 → (필요시) 패턴 설계.
저장 포맷: closes/*.json 에 dates·last_bar·n 추가됨(증분·신선도·분석용). 매칭은 여전히 closes 사용.

## 크론 동시실행 방지 (flock)
크론이 겹치거나 이전 작업 미완 시 파일 깨짐 방지. 크론 줄 앞에 flock 래핑:
```
30 7 * * 1-5 /usr/bin/flock -n /tmp/f29-patternmatch.lock -c 'cd /var/www/f29-pattern-lab && set -a && . /root/moneyflow/.env && set +a && /root/moneyflow/venv/bin/python pipeline/build_core.py --out /var/www/f29-pattern-lab/data/closes --days 90 --keep 60' >> /var/log/f29-patternmatch.log 2>&1
```
-n = 이미 실행 중이면 즉시 종료(중복 방지). build_core는 파일 단위 덮어쓰기라 부분실패 시 기존 파일 유지됨.

## 검증 상태 (verification_status) — 데이터 오염 방지
Pattern Match는 사용자가 붙인 티커를 즉시 믿지 않음. 서버 종가와 대조:
- verified: 겹치는 날짜 5+ · 종가차 중앙값 0.5% 이내 · 최신 5일 이내 → 랭킹/저커버 사용 가능
- mismatch: 불일치 → 분석만, 랭킹/저커버 금지
- unverified: 서버에 그 티커 없음 → 분석만, 저커버 금지
- anonymous: 티커 없음 → 분석만
★반자동 cluster_report·랭킹은 verified + 서버 크론 데이터만 사용. 사용자 붙여넣기는 서버 저장 안 함(경계 유지).

## 주간 저커버 감시 리포터 (내부 판단용 · 사용자 비공개)
매주 자동 실행 → PASS/WATCH/REVIEW 판정. ★패턴 JSON/퀴즈/해설 자동 생성 금지★
판정 기준 (5개는 필요조건일 뿐):
- REVIEW: 5개+ AND 응집도<=0.35(조밀) AND 평균score<62 AND top1쏠림>=70%  → 사람 검토
- WATCH: 5개+지만 흩어짐, 또는 3~4개 관찰 지속
- PASS: 후보 없음
리포트는 웹 밖(/root)에 저장 — 라이브 노출 금지.
```
# 수동 실행
node pipeline/cluster_report.js --set combined90 --out /root/f29-pattern-lab/reports

# 주간 크론 (월 08:10 UTC = 17:10 KST, 월요일 07:00 UTC build_core 이후)
10 8 * * 1 /usr/bin/flock -n /tmp/f29-weekly-report.lock -c 'cd /var/www/f29-pattern-lab && node pipeline/cluster_report.js --set combined90 --out /root/f29-pattern-lab/reports' >> /root/f29-pattern-lab/logs/cluster_report.log 2>&1
```
자동 결론은 라벨(PASS/WATCH/REVIEW)까지만. "확정/추가 필요/다음 패턴은 OOO" 금지.
