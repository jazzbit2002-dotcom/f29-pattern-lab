# F29 Pattern Match — 데이터 파이프라인 (STEP 5)

Pattern Match 에 실시간 티커 종가를 공급하는 정적+크론 파이프라인. 새 서버 프로세스(pm2) 불필요.

## 구조
```
사용자가 티커 입력
 → match.html 이 /lab/data/closes/<TICKER>.json fetch
   → 있으면(코어) 실제 종가로 매칭
   → 없으면(404) 안내 + nginx 로그에 요청 기록(=수요)
크론1(매일): build_core.js  → 코어 유니버스 종가 갱신 → data/closes/*.json
크론2(주1): analyze_demand.js → nginx 로그 404 집계 → 승격 후보 → 사람이 universe 에 추가
```

## 데이터 소스 (교체 가능)
- 기본 = **stooq** (무료·무키·일봉 CSV). 바로 동작.
- Databento 등으로 바꾸려면 `pipeline/fetchers.js` 에 어댑터 추가 후 `--source` 로 지정.
- MF 와 저장소 공유 원칙: Pattern Match 는 `data/closes/` 만 쓴다(쓰기 주체 분리).

## 최초 셋업 (VPS)
```bash
# 1) 단일 티커로 소스 동작 확인
cd /var/www/f29-pattern-lab
node -e "require('./pipeline/fetchers.js').getAdapter('stooq').fetchCloses('NVDA',60).then(c=>console.log('OK',c.length,c.slice(-3))).catch(e=>console.error('FAIL',e.message))"

# 2) 코어 유니버스 전체 빌드 (40종목, 티커당 0.4s 딜레이)
node pipeline/build_core.js --source stooq --days 60
#  → data/closes/*.json 생성. nginx 가 /lab/data/closes/ 로 서빙.

# 3) 확인
curl -s https://f29.io/lab/data/closes/NVDA.json | head -c 120; echo
```
※ 출력 위치가 nginx 서빙 폴더와 달라야 하면: `--out /var/www/f29-pattern-lab/data/closes`
※ 쓰기 권한: 크론 실행 사용자가 data/closes 에 쓸 수 있어야 함(root 또는 chown).

## 크론 (예: 미국장 마감 후 = UTC 22:00 평일)
```
# 종가 갱신 (평일 22:10 UTC)
10 22 * * 1-5  cd /var/www/f29-pattern-lab && /usr/bin/node pipeline/build_core.js --source stooq >> /var/log/f29-patternmatch.log 2>&1
# 수요 집계 (매주 월 03:00 UTC)
0 3 * * 1  cd /var/www/f29-pattern-lab && /usr/bin/node pipeline/analyze_demand.js /var/log/nginx/access.log --min 3 >> /var/log/f29-patternmatch.log 2>&1
```
※ crontab 편집은 heredoc/직접(sed 금지 — & 재삽입 문제).

## 승격 워크플로
1. `analyze_demand.js` 실행 → `pipeline/demand.json` + 승격 후보 출력
2. 후보 확인 → `pipeline/universe.core.json` tickers 에 추가
3. `node pipeline/build_core.js` 재실행 → 다음날부터 그 티커도 조회 가능
※ 자동 추가 아님(무한증식·쓰레기 티커 방지). 사람 확인 게이트.

## 무한증식 방지
- 30일간 조회 0 인 비코어 캐시는 build 대상에서 자연 제외(유니버스에 없으면 안 만듦)
- 승격은 404 수요가 min 이상일 때만
