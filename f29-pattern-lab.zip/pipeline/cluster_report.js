#!/usr/bin/env node
/* F29 Pattern Match — pipeline/cluster_report.js  [반자동: 탐지 자동 + 사람 승인]
   저커버(score<65) 종목을 형태 특성으로 클러스터링해서, 패턴 추가 "후보"를 리포트한다.
   ★패턴을 자동 생성/추가하지 않는다.★ 사람(Sky)이 리포트를 보고 판정한다.
   실행: node pipeline/cluster_report.js [--set core40|holdout50|combined90] [--out reports]
   트리거(Sky 원칙): 같은 형태 클러스터 5개 이상 + score<65 일 때만 "패턴 추가 검토" 플래그. */
const fs=require("fs"), path=require("path");
const ME=require("../js/match-engine.js");
const PDIR=path.join(__dirname,"..","data","patterns");
const CDIR=path.join(__dirname,"..","data","closes");
function arg(f,d){const i=process.argv.indexOf(f);return i>=0?process.argv[i+1]:d;}
const SET=arg("--set","combined90"), OUT=arg("--out",null);
const MIN_CLUSTER=5, DIST=0.6, LOW=65;

function loadUni(f){try{return new Set(JSON.parse(fs.readFileSync(path.join(__dirname,f),"utf8")).tickers);}catch(e){return new Set();}}
const core=loadUni("universe.core.json"), hold=loadUni("universe.holdout.json");
function inSet(t){ if(SET==="core40")return core.has(t); if(SET==="holdout50")return hold.has(t); return core.has(t)||hold.has(t); }

const byId={};
fs.readdirSync(PDIR).filter(f=>f.endsWith(".json")).forEach(f=>{const p=JSON.parse(fs.readFileSync(path.join(PDIR,f),"utf8"));byId[p.id]=p;});

const low=[];
fs.readdirSync(CDIR).filter(f=>f.endsWith(".json")).forEach(f=>{
  let d;try{d=JSON.parse(fs.readFileSync(path.join(CDIR,f),"utf8"));}catch(e){return;}
  if(d.ticker==="DEMO"||!inSet(d.ticker)||!Array.isArray(d.closes)||d.closes.length<15)return;
  const feat=ME.seriesVec(d.closes), top=ME.matchFlow(d.closes,byId,1)[0];
  if(top.score<LOW) low.push({t:d.ticker, s:top.score, best:top.title, f:feat});
});

// 그리디 클러스터링 (특성 L2 거리)
function dist(a,b){let s=0;for(let i=0;i<4;i++)s+=(a[i]-b[i])**2;return Math.sqrt(s);}
const clusters=[];
low.forEach(pt=>{
  let best=null,bd=DIST;
  clusters.forEach(c=>{const dd=dist(pt.f,c.centroid);if(dd<bd){bd=dd;best=c;}});
  if(best){best.members.push(pt);best.centroid=best.centroid.map((v,i)=>(v*(best.members.length-1)+pt.f[i])/best.members.length);}
  else clusters.push({centroid:pt.f.slice(),members:[pt]});
});
clusters.sort((a,b)=>b.members.length-a.members.length);

function hint(c){
  const [net,osc,conv,arc]=c.map(x=>Math.round(x*100)/100);
  if(net>0.35&&conv>0.3&&arc>0.4) return "상승+수렴+산형 → 둥근 고점 유형 (이미 존재, 스코어 약함일 수 있음)";
  if(net<-0.35&&arc>0.35) return "하락+골형 → ★둥근 바닥 후보 (관찰 대기 목록)";
  if(conv<-0.35) return "발산 → 확산형 유형 (이미 존재)";
  if(net>0.55&&Math.abs(arc)<0.25&&Math.abs(conv)<0.25) return "강한 추세+저진동 → 상승 플래그/채널 후보";
  if(net>0.35&&conv>0.35&&Math.abs(arc)<0.3) return "상승+수렴 → 상승 쐐기 후보";
  return "혼합형 — 명확한 단일 방향 아님 (추가 관찰 필요)";
}

const lines=[];
lines.push(`# F29 패턴 추가 후보 리포트 (반자동 탐지)`);
lines.push(`생성: ${new Date().toISOString().slice(0,10)} · dataset: ${SET} · 저커버(score<${LOW}) ${low.length}종목`);
lines.push(`트리거 기준: 같은 형태 클러스터 ${MIN_CLUSTER}개 이상 → "패턴 추가 검토" (자동 생성 안 함, 사람 판정)`);
lines.push("");
if(clusters.length===0){ lines.push("저커버 종목 없음 — 라이브러리 충분."); }
let triggered=0;
clusters.forEach((c,i)=>{
  const cen=c.centroid.map(x=>Math.round(x*100)/100);
  const trig=c.members.length>=MIN_CLUSTER;
  if(trig) triggered++;
  lines.push(`## 클러스터 ${i+1} — ${c.members.length}종목 ${trig?"★ 트리거 (검토 대상)":"(미달, 관찰)"}`);
  lines.push(`특성 중심 [net,osc,conv,arc] = [${cen.join(", ")}]`);
  lines.push(`방향 힌트: ${hint(c.centroid)}`);
  lines.push(`종목: ${c.members.map(m=>m.t+"("+m.s+")").join(", ")}`);
  lines.push("");
});
lines.push("---");
lines.push(triggered>0
  ? `판정 필요: ${triggered}개 클러스터가 트리거됨. Sky가 실제 형태 클러스터인지 확인 후 패턴 설계 결정.`
  : `조치 불필요: 트리거된 클러스터 없음 (${MIN_CLUSTER}개 이상 동일형태 없음). 패턴 추가 보류.`);
const report=lines.join("\n");
console.log(report);
if(OUT){
  const dir=path.join(__dirname,"..",OUT); fs.mkdirSync(dir,{recursive:true});
  const fp=path.join(dir,"cluster_"+new Date().toISOString().slice(0,10)+".md");
  fs.writeFileSync(fp,report);
  console.log("\n리포트 저장:",fp);
}
