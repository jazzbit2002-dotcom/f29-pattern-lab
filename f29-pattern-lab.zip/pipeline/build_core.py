#!/usr/bin/env python3
# F29 Pattern Match — pipeline/build_core.py
# 코어 유니버스의 최근 N일 종가를 Databento(DBEQ.BASIC, ohlcv-1d)로 받아
# data/closes/<TICKER>.json 으로 저장(정적, nginx 서빙).
# MF(~/moneyflow/fetch_daily.py)의 거래량가중 통합 로직 재사용.
#
# 실행 (MF venv 사용):
#   ~/moneyflow/venv/bin/python pipeline/build_core.py [--days 90] [--out DIR] [--force] [--batch 25]
#   ※ DATABENTO_API_KEY 환경변수 필요 (MF와 동일)
import os, sys, json, argparse, datetime
import databento as db
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
DATASET = "DBEQ.BASIC"
SCHEMA  = "ohlcv-1d"

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=90)      # 달력일. 거래일 60개 확보 위해 넉넉히
    ap.add_argument("--out", default=os.path.join(HERE, "..", "data", "closes"))
    ap.add_argument("--batch", type=int, default=25)     # 심볼 배치(요청 수 절약)
    ap.add_argument("--keep", type=int, default=60)      # 저장할 최근 종가 개수
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--universe", default=os.path.join(HERE, "universe.core.json"))
    return ap.parse_args()

def consolidate(df):
    """venue별 일봉을 ts_event+symbol로 거래량가중 통합 (MF fetch_daily.py 로직)."""
    def agg(g):
        v = g["volume"].sum()
        if v > 0:
            close = (g["close"] * g["volume"]).sum() / v
        else:
            close = g["close"].mean()
        return pd.Series({"close": round(float(close), 2), "volume": int(v)})
    out = df.groupby(["ts_event", "symbol"]).apply(agg, include_groups=False)
    return out.reset_index()

def main():
    a = parse_args()
    uni = json.load(open(a.universe))["tickers"]
    os.makedirs(a.out, exist_ok=True)
    today = datetime.date.today().isoformat()
    client = db.Historical()  # DATABENTO_API_KEY 환경변수

    # end = 데이터셋 가용 마지막 날짜 (주말·공휴일 자동 처리). 고정 -1일 방식은 월요일/연휴에 깨짐.
    def fallback_end():
        d = datetime.date.today() - datetime.timedelta(days=1)   # 어제부터
        while d.weekday() >= 5:                                   # 토(5)·일(6)이면 더 뒤로
            d -= datetime.timedelta(days=1)
        return d.isoformat()                                     # 최근 거래일(월요일이면 금요일)
    try:
        rng = client.metadata.get_dataset_range(dataset=DATASET)
        end_raw = None
        if isinstance(rng, dict):
            for k in ("end", "available_end", "end_date"):
                if rng.get(k):
                    end_raw = rng[k]; break
        end = str(end_raw)[:10] if end_raw else fallback_end()
    except Exception as e:
        print("available_end 조회 실패 → fallback:", e)
        end = fallback_end()
    end_d = datetime.date.fromisoformat(end)
    start = (end_d - datetime.timedelta(days=a.days)).isoformat()

    # resume: 오늘 이미 갱신된 티커 스킵
    todo = []
    for t in uni:
        f = os.path.join(a.out, t + ".json")
        if not a.force and os.path.exists(f):
            try:
                if json.load(open(f)).get("updated") == today:
                    continue
            except Exception:
                pass
        todo.append(t)
    if not todo:
        print("모두 최신. 갱신할 티커 없음.")
        return

    print(f"── build_core.py: {len(todo)}종목 · {DATASET}/{SCHEMA} · {start}~{end} (가용 끝 기준) ──")

    ok = fail = 0; failed = []
    # 배치로 한 번에 요청 → ts_event/symbol 통합 → 심볼별 종가 저장
    for i in range(0, len(todo), a.batch):
        batch = todo[i:i+a.batch]
        try:
            data = client.timeseries.get_range(
                dataset=DATASET, symbols=batch, schema=SCHEMA, start=start, end=end,
            )
            df = data.to_df().reset_index()
            if df.empty:
                raise RuntimeError("empty response")
            con = consolidate(df)
            for t in batch:
                sub = con[con["symbol"] == t].sort_values("ts_event")
                closes = [round(float(x), 2) for x in sub["close"].tolist()]
                closes = closes[-a.keep:]
                if len(closes) < 15:
                    fail += 1; failed.append(f"{t}:few({len(closes)})"); continue
                f = os.path.join(a.out, t + ".json")
                json.dump({"ticker": t, "updated": today, "source": "databento",
                           "closes": closes}, open(f, "w"))
                ok += 1; sys.stdout.write("✓"+t+" ")
        except Exception as e:
            for t in batch: failed.append(f"{t}:{e}")
            fail += len(batch); sys.stdout.write("✗batch("+",".join(batch)+") ")
        sys.stdout.flush()

    print(f"\n── 완료: 성공 {ok}, 실패 {fail} ──")
    if failed:
        print("실패:", " | ".join(failed[:15]) + (" ..." if len(failed) > 15 else ""))

if __name__ == "__main__":
    main()
