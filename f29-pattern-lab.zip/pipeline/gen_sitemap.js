#!/usr/bin/env node
/* F29 Pattern Lab 사이트맵 생성기.
   실행: node pipeline/gen_sitemap.js  → /lab/sitemap.xml 생성
   패턴이 추가/변경되면 다시 실행하면 됨. */
const fs=require("fs"), path=require("path");
const BASE="https://f29.io/lab";
const PDIR=path.join(__dirname,"..","data","patterns");
const today=new Date().toISOString().slice(0,10);

// 패턴 딥링크 목록 (order 순)
const pats=fs.readdirSync(PDIR).filter(f=>f.endsWith(".json"))
  .map(f=>JSON.parse(fs.readFileSync(path.join(PDIR,f),"utf8")))
  .sort((a,b)=>(a.order||999)-(b.order||999));

function url(loc,lastmod,freq,prio){
  return `  <url>\n    <loc>${loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>${freq}</changefreq>\n    <priority>${prio}</priority>\n  </url>`;
}
function esc(s){ return s.replace(/&/g,"&amp;"); }

const urls=[];
// 메인 페이지 2개 (높은 우선순위)
urls.push(url(BASE+"/", today, "weekly", "0.9"));
urls.push(url(BASE+"/match.html", today, "weekly", "0.9"));
// 패턴 도감 딥링크 (교육 콘텐츠, 중간 우선순위)
pats.forEach(p=>{
  urls.push(url(esc(BASE+"/?p="+p.id), today, "monthly", "0.6"));
});

const xml=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.join("\n")}
</urlset>\n`;

const out=path.join(__dirname,"..","sitemap.xml");
fs.writeFileSync(out,xml);
console.log("사이트맵 생성:", out);
console.log("URL 개수:", urls.length, "(메인 2 + 패턴 "+pats.length+")");
console.log("\n=== 미리보기 ===\n"+xml);
