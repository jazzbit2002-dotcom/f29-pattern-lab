/* F29 Pattern Match — pipeline/fetchers.js
   종가 소스 어댑터. 데이터 소스는 교체 가능(플러그블).
   기본 = stooq (무료·무키·일봉 CSV). Databento 등으로 교체 시 이 파일만 수정.
   각 어댑터: async fetchCloses(ticker, n) → number[] (최근 n 종가, 과거→최신 순) */
const https=require("https");

function get(url){
  return new Promise((resolve,reject)=>{
    https.get(url,{headers:{"User-Agent":"f29-pattern-match/1.0"}},res=>{
      if(res.statusCode>=300&&res.statusCode<400&&res.headers.location){ get(res.headers.location).then(resolve,reject); return; }
      if(res.statusCode!==200){ reject(new Error("http "+res.statusCode)); res.resume(); return; }
      let d=""; res.on("data",c=>d+=c); res.on("end",()=>resolve(d));
    }).on("error",reject);
  });
}

// stooq 일봉 CSV 파싱: Date,Open,High,Low,Close,Volume
function parseStooqCSV(text){
  const lines=String(text).trim().split(/\r?\n/);
  if(lines.length<2) return [];
  const head=lines[0].split(",").map(s=>s.trim().toLowerCase());
  const ci=head.indexOf("close");
  if(ci<0) return [];
  const out=[];
  for(let i=1;i<lines.length;i++){
    const cols=lines[i].split(",");
    const v=parseFloat(cols[ci]);
    if(isFinite(v)) out.push(v);
  }
  return out; // 과거→최신
}

const stooq={
  name:"stooq",
  async fetchCloses(ticker, n){
    const sym=encodeURIComponent(ticker.toLowerCase())+".us";
    const csv=await get("https://stooq.com/q/d/l/?s="+sym+"&i=d");
    const closes=parseStooqCSV(csv);
    if(!closes.length) throw new Error("no data: "+ticker);
    return closes.slice(-n);
  }
};

// 테스트/오프라인용 결정론적 mock
const mock={
  name:"mock",
  async fetchCloses(ticker, n){
    let seed=0; for(const ch of ticker) seed=(seed*31+ch.charCodeAt(0))%997;
    const out=[]; let p=100;
    for(let i=0;i<n;i++){ seed=(seed*1103515245+12345)%2147483648; p+=((seed%1000)/1000-0.45)*4; out.push(Math.round(p*100)/100); }
    return out;
  }
};

const ADAPTERS={stooq, mock};
function getAdapter(name){ return ADAPTERS[name]||stooq; }

module.exports={ getAdapter, parseStooqCSV, stooq, mock };
