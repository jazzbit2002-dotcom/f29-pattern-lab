#!/usr/bin/env node
/* F29 Pattern Match — pipeline/analyze_demand.js
   nginx access log 에서 /lab/data/closes/<TICKER>.json 요청을 집계.
   - 404(없는 티커) = 온디맨드 수요 → 승격 후보
   - 200 = 기존 코어 사용량
   사용: node pipeline/analyze_demand.js /var/log/nginx/access.log [--min 3]
   출력: pipeline/demand.json (티커별 조회수·404수·고유일수) + 승격 후보 목록.
   승격 = min 이상 404 난 티커를 universe.core.json 에 추가 후보로 제안(자동 추가 아님, 사람 확인). */
const fs=require("fs"), path=require("path");
const LOG=process.argv[2]||"/var/log/nginx/access.log";
const MIN=parseInt((process.argv.indexOf("--min")>=0?process.argv[process.argv.indexOf("--min")+1]:"3"),10);
const RE=/"GET \/lab\/data\/closes\/([A-Z0-9.\-]+)\.json[^"]*" (\d{3})/;
const DATE=/\[(\d{2}\/\w{3}\/\d{4})/;

function main(){
  if(!fs.existsSync(LOG)){ console.error("로그 없음:",LOG); process.exit(1); }
  const lines=fs.readFileSync(LOG,"utf8").split(/\r?\n/);
  const tally={};
  for(const ln of lines){
    const m=ln.match(RE); if(!m) continue;
    const tk=m[1], st=m[2], dm=(ln.match(DATE)||[])[1]||"?";
    const e=tally[tk]||(tally[tk]={ticker:tk,hits:0,miss:0,days:new Set()});
    e.hits++; if(st==="404") e.miss++; e.days.add(dm);
  }
  const rows=Object.values(tally).map(e=>({ticker:e.ticker,hits:e.hits,miss:e.miss,uniqueDays:e.days.size}))
    .sort((a,b)=>b.miss-a.miss||b.hits-a.hits);
  fs.writeFileSync(path.join(__dirname,"demand.json"), JSON.stringify({generated:new Date().toISOString(),rows},null,2));

  const core=new Set(JSON.parse(fs.readFileSync(path.join(__dirname,"universe.core.json"),"utf8")).tickers);
  const promote=rows.filter(r=>r.miss>=MIN && !core.has(r.ticker)).map(r=>r.ticker);
  console.log(`── 수요 분석: ${rows.length}티커 · 로그 ${LOG} ──`);
  console.log("상위 수요:", rows.slice(0,10).map(r=>`${r.ticker}(조회${r.hits}/미스${r.miss}/${r.uniqueDays}일)`).join(" "));
  console.log(`승격 후보(404≥${MIN}, 코어에 없음):`, promote.length?promote.join(" "):"(없음)");
  console.log("→ pipeline/demand.json 저장. 후보 확인 후 universe.core.json 에 추가하고 build_core 재실행.");
}
main();
