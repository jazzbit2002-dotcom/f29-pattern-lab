#!/usr/bin/env node
/* F29 Pattern Match — pipeline/analyze_shapes.js
   data/closes/*.json (실데이터 40종목)의 형태를 분석해, 현재 패턴 라이브러리가
   못 잡는(낮은 유사도) 흐름을 찾아낸다. → 어떤 패턴을 우선 추가할지 데이터로 결정.
   실행: node pipeline/analyze_shapes.js
   출력: 종목별 최고매칭·점수·형태특성, 커버리지 분포, 저커버 종목의 특성 클러스터 */
const fs=require("fs"), path=require("path");
const ME=require("../js/match-engine.js");

const PDIR=path.join(__dirname,"..","data","patterns");
const CDIR=path.join(__dirname,"..","data","closes");

const byId={};
fs.readdirSync(PDIR).filter(f=>f.endsWith(".json")).forEach(f=>{
  const p=JSON.parse(fs.readFileSync(path.join(PDIR,f),"utf8")); byId[p.id]=p;
});

const files=fs.readdirSync(CDIR).filter(f=>f.endsWith(".json"));
const rows=[];
for(const f of files){
  let d; try{ d=JSON.parse(fs.readFileSync(path.join(CDIR,f),"utf8")); }catch(e){ continue; }
  if(!Array.isArray(d.closes)||d.closes.length<15) continue;
  const feat=ME.seriesVec(d.closes).map(x=>Math.round(x*100)/100);
  const top3=ME.matchFlow(d.closes, byId, 3);
  rows.push({t:d.ticker, best:top3[0].title, s:top3[0].score,
             top3:top3.map(m=>m.title+" "+m.score).join(", "), feat});
}
rows.sort((a,b)=>a.s-b.s);

console.log("=== 종목별 최고매칭 (낮은 점수 = 라이브러리가 못 잡는 형태) ===");
console.log("ticker  best              score   [net, osc, conv, arc]");
rows.forEach(r=>console.log(
  r.t.padEnd(7), r.best.padEnd(16), String(r.s).padStart(3),
  "   ["+r.feat.join(", ")+"]"));

// 커버리지 분포
const b={low:0,mid:0,hi:0};
rows.forEach(r=>{ if(r.s<45)b.low++; else if(r.s<65)b.mid++; else b.hi++; });
console.log(`\n=== 커버리지: 40+ 미만(못잡음) ${b.low} · 45~64 ${b.mid} · 65+ (잘잡음) ${b.hi} / 총 ${rows.length} ===`);

// 저커버(점수<50) 종목의 특성 평균 → 어떤 형태가 부족한지
const low=rows.filter(r=>r.s<50);
if(low.length){
  const avg=[0,1,2,3].map(i=>Math.round(low.reduce((s,r)=>s+r.feat[i],0)/low.length*100)/100);
  console.log(`\n=== 저커버 ${low.length}종목 평균 특성 [net,osc,conv,arc] = [${avg.join(", ")}] ===`);
  console.log("해석 힌트: net>0.4=강한상승추세 / osc>0.5=진동많음 / arc>0.4=산형 / arc<-0.4=골형 / conv>0.3=수렴");
  console.log("저커버 종목:", low.map(r=>r.t).join(" "));
}

// 현재 패턴별 "1위로 뽑힌 횟수" → 안 뽑히는 패턴 = 실제로 잘 안 나타남
const win={}; rows.forEach(r=>win[r.best]=(win[r.best]||0)+1);
console.log("\n=== 현재 패턴별 1위 횟수 ===");
Object.entries(win).sort((a,b)=>b[1]-a[1]).forEach(([k,v])=>console.log("  "+k+": "+v));
