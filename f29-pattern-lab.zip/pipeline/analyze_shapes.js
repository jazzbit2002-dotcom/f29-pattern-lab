#!/usr/bin/env node
/* F29 Pattern Match — pipeline/analyze_shapes.js
   data/closes/*.json (실데이터 40종목)의 형태를 분석해, 현재 패턴 라이브러리가
   못 잡는(낮은 유사도) 흐름을 찾아낸다. → 어떤 패턴을 우선 추가할지 데이터로 결정.
   실행: node pipeline/analyze_shapes.js
   출력: 종목별 최고매칭·점수·형태특성, 커버리지 분포, 저커버 종목의 특성 클러스터 */
const fs=require("fs"), path=require("path");
const ME=require("../js/match-engine.js");

const PDIR=path.join(__dirname,"..","data","patterns");
const CDIR=path.join(__dirname,"..","data","closes");

// --set core40 | holdout50 | combined90  (기본 core40)
function arg(flag,def){ const i=process.argv.indexOf(flag); return i>=0?process.argv[i+1]:def; }
const SET=arg("--set","core40");
function loadUni(f){ try{ return new Set(JSON.parse(fs.readFileSync(path.join(__dirname,f),"utf8")).tickers); }catch(e){ return new Set(); } }
const core=loadUni("universe.core.json"), hold=loadUni("universe.holdout.json");
function inSet(tk){
  if(SET==="core40") return core.has(tk);
  if(SET==="holdout50") return hold.has(tk);
  return core.has(tk)||hold.has(tk); // combined90
}
const LABEL={core40:"core40 (학습/개선 세트)", holdout50:"holdout50 (일반화 검증 세트)", combined90:"combined90 (전체)"}[SET]||SET;

const byId={};
fs.readdirSync(PDIR).filter(f=>f.endsWith(".json")).forEach(f=>{
  const p=JSON.parse(fs.readFileSync(path.join(PDIR,f),"utf8")); byId[p.id]=p;
});

const files=fs.readdirSync(CDIR).filter(f=>f.endsWith(".json"));
const rows=[];
for(const f of files){
  let d; try{ d=JSON.parse(fs.readFileSync(path.join(CDIR,f),"utf8")); }catch(e){ continue; }
  if(d.ticker==="DEMO") continue;   // 데모 플레이스홀더 제외
  if(!inSet(d.ticker)) continue;    // --set 필터
  if(!Array.isArray(d.closes)||d.closes.length<15) continue;
  const feat=ME.seriesVec(d.closes).map(x=>Math.round(x*100)/100);
  const top3=ME.matchFlow(d.closes, byId, 3);
  rows.push({t:d.ticker, best:top3[0].title, s:top3[0].score,
             top3:top3.map(m=>m.title+" "+m.score).join(", "), feat});
}
rows.sort((a,b)=>a.s-b.s);

console.log(`dataset: ${LABEL}  ·  분석 ${rows.length}종목\n`);

// ── 판정 기준 3블록 ──

// 판정선: set별
const TH={
  core40:   {low:1, mid:6,  hi:34, skewWarn:15, skewMax:12},
  holdout50:{low:2, mid:8,  hi:40, skewWarn:18, skewMax:18},
  combined90:{low:3, mid:14, hi:74, skewWarn:27, skewMax:27}
}[SET] || {low:1, mid:6, hi:34, skewWarn:15, skewMax:12};

// [1] 커버리지 분포 (못잡음<45 / 보통 45~64 / 잘잡음>=65)
const cov={low:0,mid:0,hi:0};
rows.forEach(r=>{ if(r.s<45)cov.low++; else if(r.s<65)cov.mid++; else cov.hi++; });
const N=rows.length;
console.log("=== [1] 커버리지 분포 ===");
console.log(`  못잡음(<45): ${cov.low}   보통(45~64): ${cov.mid}   잘잡음(>=65): ${cov.hi}   / 총 ${N}`);
console.log(`  판정선(${SET}): 못잡음 <=${TH.low} · 보통 <=${TH.mid} · 잘잡음 >=${TH.hi}  →  ${(cov.low<=TH.low&&cov.mid<=TH.mid&&cov.hi>=TH.hi)?"통과":"미달(2차 검토)"}`);

// [2] top1 패턴 카운트 (쏠림)
const win={}; rows.forEach(r=>win[r.best]=(win[r.best]||0)+1);
const wsorted=Object.entries(win).sort((a,b)=>b[1]-a[1]);
console.log("\n=== [2] top1 패턴 카운트 ===");
wsorted.forEach(([k,v])=>console.log("  "+k.padEnd(12)+" "+v+(v>=TH.skewWarn?"  ← 쏠림 경고":"")));
console.log(`  최다 점유: ${wsorted[0][0]} ${wsorted[0][1]}/${N}  →  ${wsorted[0][1]<=TH.skewMax?"양호":"쏠림(억지매칭 가능 — [3]에 클러스터 있는지 확인)"}`);

// [3] score<65 종목 목록 (남은 클러스터 후보 — ticker/top1/score/signature)
const under=rows.filter(r=>r.s<65);
console.log(`\n=== [3] score<65 종목 (${under.length}개) — 남은 클러스터 후보 ===`);
console.log("ticker  top1              score   [net, osc, conv, arc]");
under.forEach(r=>console.log(
  r.t.padEnd(7), r.best.padEnd(16), String(r.s).padStart(3),
  "   ["+r.feat.join(", ")+"]"));
console.log("\n(2차 확장은 이 목록에서 '같은 형태 클러스터'가 보일 때만. 이름이 아니라 클러스터가 결정.)");
