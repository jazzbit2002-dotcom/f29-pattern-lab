#!/usr/bin/env node
/* F29 Pattern Match — pipeline/analyze_shapes.js
   data/closes/*.json (실데이터 40종목)의 형태를 분석해, 현재 패턴 라이브러리가
   못 잡는(낮은 유사도) 흐름을 찾아낸다. → 어떤 패턴을 우선 추가할지 데이터로 결정.
   실행: node pipeline/analyze_shapes.js
   출력: 종목별 최고매칭·점수·형태특성, 커버리지 분포, 저커버 종목의 특성 클러스터 */
const fs=require("fs"), path=require("path");
const ME=require("../js/match-engine.js");

const PDIR=path.join(__dirname,"..","data","patterns");
const CDIR=path.join(__dirname,"..","data","closes");

const byId={};
fs.readdirSync(PDIR).filter(f=>f.endsWith(".json")).forEach(f=>{
  const p=JSON.parse(fs.readFileSync(path.join(PDIR,f),"utf8")); byId[p.id]=p;
});

const files=fs.readdirSync(CDIR).filter(f=>f.endsWith(".json"));
const rows=[];
for(const f of files){
  let d; try{ d=JSON.parse(fs.readFileSync(path.join(CDIR,f),"utf8")); }catch(e){ continue; }
  if(d.ticker==="DEMO") continue;   // 데모 플레이스홀더 제외
  if(!Array.isArray(d.closes)||d.closes.length<15) continue;
  const feat=ME.seriesVec(d.closes).map(x=>Math.round(x*100)/100);
  const top3=ME.matchFlow(d.closes, byId, 3);
  rows.push({t:d.ticker, best:top3[0].title, s:top3[0].score,
             top3:top3.map(m=>m.title+" "+m.score).join(", "), feat});
}
rows.sort((a,b)=>a.s-b.s);

// ── 판정 기준 3블록 ──

// [1] 커버리지 분포 (못잡음<45 / 보통 45~64 / 잘잡음>=65)
const cov={low:0,mid:0,hi:0};
rows.forEach(r=>{ if(r.s<45)cov.low++; else if(r.s<65)cov.mid++; else cov.hi++; });
const N=rows.length;
console.log("=== [1] 커버리지 분포 ===");
console.log(`  못잡음(<45): ${cov.low}   보통(45~64): ${cov.mid}   잘잡음(>=65): ${cov.hi}   / 총 ${N}`);
console.log(`  판정선: 못잡음 0~1 / 보통 <=6 / 잘잡음 >=34  →  ${(cov.low<=1&&cov.mid<=6&&cov.hi>=34)?"통과(확장 중단 가능)":"미달(2차 검토)"}`);

// [2] top1 패턴 카운트 (쏠림 = 단일 패턴 >=15 위험, 기준 <=12)
const win={}; rows.forEach(r=>win[r.best]=(win[r.best]||0)+1);
const wsorted=Object.entries(win).sort((a,b)=>b[1]-a[1]);
console.log("\n=== [2] top1 패턴 카운트 ===");
wsorted.forEach(([k,v])=>console.log("  "+k.padEnd(12)+" "+v+(v>=15?"  ← 쏠림 경고":"")));
console.log(`  최다 점유: ${wsorted[0][0]} ${wsorted[0][1]}/${N}  →  ${wsorted[0][1]<=12?"양호(<=12)":"쏠림(>12, 억지매칭 가능)"}`);

// [3] score<65 종목 목록 (남은 클러스터 후보 — ticker/top1/score/signature)
const under=rows.filter(r=>r.s<65);
console.log(`\n=== [3] score<65 종목 (${under.length}개) — 남은 클러스터 후보 ===`);
console.log("ticker  top1              score   [net, osc, conv, arc]");
under.forEach(r=>console.log(
  r.t.padEnd(7), r.best.padEnd(16), String(r.s).padStart(3),
  "   ["+r.feat.join(", ")+"]"));
console.log("\n(2차 확장은 이 목록에서 '같은 형태 클러스터'가 보일 때만. 이름이 아니라 클러스터가 결정.)");
