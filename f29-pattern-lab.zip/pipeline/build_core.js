#!/usr/bin/env node
/* F29 Pattern Match — pipeline/build_core.js
   코어 유니버스의 최근 N일 종가를 받아 data/closes/<TICKER>.json 으로 저장(정적, nginx 서빙).
   사용: node pipeline/build_core.js [--source stooq|mock] [--days 60] [--delay 400]
   - rate limit: 티커 간 delay ms
   - resumable: 오늘 갱신된 파일은 건너뜀(--force 로 무시)
   - 실패는 건너뛰고 계속(부분 성공 허용), 요약 출력 */
const fs=require("fs"), path=require("path");
const { getAdapter }=require("./fetchers.js");

function arg(flag,def){ const i=process.argv.indexOf(flag); return i>=0?process.argv[i+1]:def; }
const SOURCE=arg("--source","stooq"), DAYS=parseInt(arg("--days","60"),10), DELAY=parseInt(arg("--delay","400"),10);
const FORCE=process.argv.includes("--force");
// 출력 경로: 기본은 이 리포의 data/closes. nginx 서빙 위치가 다르면 --out 로 지정.
const OUT=arg("--out", path.join(__dirname,"..","data","closes"));
const today=new Date().toISOString().slice(0,10);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

async function main(){
  const uni=JSON.parse(fs.readFileSync(path.join(__dirname,"universe.core.json"),"utf8")).tickers;
  const adapter=getAdapter(SOURCE);
  fs.mkdirSync(OUT,{recursive:true});
  let ok=0,skip=0,fail=0; const failed=[];
  console.log(`── build_core: ${uni.length}종목 · source=${adapter.name} · days=${DAYS} ──`);
  for(const t of uni){
    const f=path.join(OUT,t+".json");
    if(!FORCE && fs.existsSync(f)){
      try{ if(JSON.parse(fs.readFileSync(f,"utf8")).updated===today){ skip++; continue; } }catch(e){}
    }
    try{
      const closes=await adapter.fetchCloses(t, DAYS);
      if(!closes||closes.length<15) throw new Error("too few ("+(closes?closes.length:0)+")");
      fs.writeFileSync(f, JSON.stringify({ticker:t,updated:today,source:adapter.name,closes}));
      ok++; process.stdout.write("✓"+t+" ");
    }catch(e){ fail++; failed.push(t+":"+e.message); process.stdout.write("✗"+t+" "); }
    await sleep(DELAY);
  }
  console.log(`\n── 완료: 성공 ${ok}, 건너뜀 ${skip}, 실패 ${fail} ──`);
  if(failed.length) console.log("실패 상세:", failed.join(" | "));
}
main();
