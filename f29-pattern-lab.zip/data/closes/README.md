# data/closes/ — Pattern Match 종가 캐시

각 파일: <TICKER>.json = { ticker, updated(YYYY-MM-DD), source, closes:[최근 N일 종가] }
- 코어 유니버스는 크론(pipeline/build_core.js)이 매일 생성/갱신
- match.html 이 /lab/data/closes/<TICKER>.json 을 fetch → 매칭
- 없는 티커 요청(404)은 nginx 로그에 남고, pipeline/analyze_demand.js 가 수요 집계 → 승격 후보
- 이 폴더는 크론 산출물. 실데이터는 서버에서 채워짐. (DEMO.json 은 구조 확인용 예시)
