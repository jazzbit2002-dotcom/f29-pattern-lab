#!/usr/bin/env node
/* summarize_pattern_history.js — 판정 안정도(Pattern Stability) 지표 리포트.
   ★예측 적중률이 아니라 "형태 판정이 며칠간 안정적인가"만 측정.★
   히스토리 JSONL을 종목별 시계열로 재구성 → 안정도 지표 산출.
   실행: node tools/summarize_pattern_history.js [--hist DIR] [--window 10] [--out DIR]
   지표(모두 형태 일관성, 방향 예측 아님):
     top1_stability    최근 N회 중 최빈 top1 비율 (높을수록 형태 뚜렷)
     switch_count      최근 N회 top1 전환 횟수 (많을수록 불안정)
     gap12_avg         top1-top2 평균 점수차 (클수록 분류 명확)
     low_coverage_streak  score<65 연속 일수 (도감이 못 잡는 흐름) */
const fs=require("fs"), path=require("path");
function arg(f,d){const i=process.argv.indexOf(f);return i>=0?process.argv[i+1]:d;}
const HIST=arg("--hist","/root/f29-pattern-lab/history/pattern_judgments");
const WIN=parseInt(arg("--window","10"),10);
const OUT=arg("--out",null);
const LOW=65;

let files;
try{ files=fs.readdirSync(HIST).filter(f=>/^\d{4}-\d{2}-\d{2}\.jsonl$/.test(f)).sort(); }
catch(e){ console.error("히스토리 폴더 없음:",HIST); process.exit(1); }
if(files.length===0){ console.error("기록된 히스토리 없음. record_pattern_history.js 를 며칠 돌린 뒤 실행."); process.exit(1); }

// 종목별 시계열 재구성 (날짜순)
const series={};  // ticker -> [{date, top1, score1, gap12, structure}...]
files.forEach(f=>{
  fs.readFileSync(path.join(HIST,f),"utf8").trim().split("\n").forEach(line=>{
    if(!line)return; let r; try{r=JSON.parse(line);}catch(e){return;}
    (series[r.ticker]=series[r.ticker]||[]).push({
      date:r.date, top1:r.top1?r.top1.pattern_title:null, score1:r.top1?r.top1.score:null,
      gap12:r.gap12, structure:r.structure
    });
  });
});

function mode(arr){const c={};let best=null,bn=0;arr.forEach(x=>{c[x]=(c[x]||0)+1;if(c[x]>bn){bn=c[x];best=x;}});return {val:best,count:bn};}

const out=[];
Object.keys(series).sort().forEach(t=>{
  const s=series[t].slice(-WIN);           // 최근 N회
  const n=s.length;
  const tops=s.map(x=>x.top1);
  const m=mode(tops);
  const stability=Math.round(m.count/n*100);       // 최빈 top1 비율(%)
  let switches=0; for(let i=1;i<tops.length;i++) if(tops[i]!==tops[i-1]) switches++;
  const gapAvg=Math.round(s.reduce((a,x)=>a+(x.gap12||0),0)/n*10)/10;
  // 저커버 연속: 뒤에서부터 score1<65 연속 카운트
  let streak=0; for(let i=s.length-1;i>=0;i--){ if(s[i].score1!=null&&s[i].score1<LOW)streak++; else break; }
  out.push({t, n, top:m.val, stability, switches, gapAvg, streak, last:s[s.length-1]});
});

// 정렬: 불안정한 것(전환 많음/안정도 낮음) 먼저 → 주목 필요
out.sort((a,b)=> a.stability-b.stability || b.switches-a.switches);

const today=new Date().toISOString().slice(0,10);
const L=[];
L.push(`# F29 패턴 판정 안정도 리포트 (형태 일관성 · 내부 전용)`);
L.push(`생성: ${today} · 관측창: 최근 ${WIN}회 · 대상: ${out.length}종목 · 누적 ${files.length}일`);
L.push(`※ 이 지표는 형태 판정 안정도이며, 방향 예측/적중률이 아닙니다.`);
L.push("");
L.push(`## 판정이 불안정한 종목 (형태 애매 — 주목)`);
L.push(`안정도 = 최근 ${WIN}회 중 최빈 패턴 비율. 낮을수록 형태가 자주 바뀜.`);
out.filter(x=>x.stability<60||x.switches>=3).forEach(x=>{
  L.push(`- ${x.t}: 안정도 ${x.stability}% · 전환 ${x.switches}회 · 최빈 "${x.top}" · gap평균 ${x.gapAvg}${x.streak>=3?` · 저커버 ${x.streak}일연속`:""}`);
});
L.push("");
L.push(`## 판정이 안정적인 종목 (형태 뚜렷)`);
out.filter(x=>x.stability>=80&&x.switches<=1).forEach(x=>{
  L.push(`- ${x.t}: 안정도 ${x.stability}% · "${x.top}" 유지 · gap평균 ${x.gapAvg}`);
});
L.push("");
L.push(`## 저커버 지속 (도감이 잘 못 잡는 흐름 · 주간 리포터와 연결)`);
const streaks=out.filter(x=>x.streak>=3).sort((a,b)=>b.streak-a.streak);
if(streaks.length) streaks.forEach(x=>L.push(`- ${x.t}: score<${LOW} ${x.streak}일 연속 · 현재 top1 "${x.top}"`));
else L.push(`- (없음)`);
L.push("");
L.push(`## 표시 문구 원칙 (UI 노출 시)`);
L.push(`✓ "최근 ${WIN}회 중 N회 같은 패턴으로 분류 · 형태 판정 안정적"`);
L.push(`✗ "이 패턴 신뢰도 N%" / "적중률 N%" — 금지 (예측 오해)`);

const report=L.join("\n");
console.log(report);
if(OUT){ const dir=path.isAbsolute(OUT)?OUT:path.join(__dirname,"..",OUT); fs.mkdirSync(dir,{recursive:true});
  const fp=path.join(dir,"stability_"+today+".md"); fs.writeFileSync(fp,report); console.log("\n리포트 저장:",fp); }
