# F29 Pattern Lab — 배포 가이드 (정적 서빙)

Pattern Lab은 순수 정적입니다. node 프로세스/pm2 불필요. nginx로 파일만 서빙합니다.
패턴을 추가/수정할 때만 로컬에서 `node build.js` 로 patterns-bundle.js 재생성 후 커밋하세요.

## 라우트
- 서빙 경로: https://f29.io/lab/
- 상대경로(js/, data/)를 쓰므로 반드시 끝에 슬래시(/lab/)로 접근. no-slash는 리다이렉트 처리.

## nginx 블록 (sites-enabled/f29 의 https server{} 안, catch-all location / 보다 위)
```nginx
    # ── F29 Pattern Lab (정적) ──
    location = /lab { return 301 /lab/; }
    location /lab/ {
        alias /var/www/f29-pattern-lab/;
        index index.html;
    }
```
※ prefix 매칭은 최장일치라 순서 무관하지만 가독성 위해 위에 둠.
※ 클론 위치를 바꾸면 alias 경로도 같이 바꿀 것.

## 패턴 추가 워크플로 (나중에)
```
# 로컬
vi data/patterns/새패턴.json      # order 필수
node build.js                      # 검증+린트 통과해야 번들 생성
git add . && git commit -m "add 새패턴" && git push
# 서버
cd /var/www/f29-pattern-lab && sudo git pull
```
