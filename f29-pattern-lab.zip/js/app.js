/* F29 Pattern Lab — app.js  부트스트랩. 매니페스트로 패턴 선택기 구성 → 선택 패턴 로드·마운트. */
(function(root){
  var F=(root.F29=root.F29||{});
  function buildPatternSelector(manifest,current,onPick){
    var el=document.getElementById("patternsel"); if(!el) return;
    el.innerHTML="";
    manifest.forEach(function(m){
      var b=document.createElement("button");
      b.type="button"; b.textContent=m.title; b.dataset.id=m.id;
      if(m.id===current) b.className="on";
      b.addEventListener("click",function(){ onPick(m.id); });
      el.appendChild(b);
    });
  }
  function setSelActive(id){
    var el=document.getElementById("patternsel"); if(!el) return;
    el.querySelectorAll("button").forEach(function(b){ b.classList.toggle("on",b.dataset.id===id); });
  }
  async function go(id){
    try{
      var p=await F.PatternLoader.load(id);
      F.PatternEngine.mount(p);
      setSelActive(id);
    }catch(e){
      console.error("패턴 로드 실패:",id,e);
      document.getElementById("readout").innerHTML='<div class="sdesc">패턴 데이터를 불러오지 못했습니다. data/patterns/ 경로를 확인하세요.</div>';
    }
  }
  document.addEventListener("DOMContentLoaded",function(){
    var manifest=F.PatternLoader.manifest();
    var ids=manifest.map(function(m){return m.id;});
    var want=null;
    try{ want=new URLSearchParams(location.search).get("p"); }catch(e){}
    var first=(want&&ids.indexOf(want)>=0)?want:((manifest[0]&&manifest[0].id)||"head-and-shoulders");
    buildPatternSelector(manifest,first,go);
    go(first);
  });
})(window);
