/* F29 Pattern Match — match-engine.js
   입력 가격 흐름을 학습용 패턴의 기준형태와 비교해 유사도(형태 닮음 점수) 나열.
   판독·확정·방향 제시 안 함. 유사도는 확률이 아니다.
   기준형태 = 패턴 basePath + 첫 상태 structurePath (교과서 형태), N점 리샘플 후 0~100 정규화.
   유사도 = 정규화 벡터 간 피어슨 상관 → max(0,r)*100. (스케일·offset 무관, 모양만)
   node/browser 겸용(UMD). */
(function(root){
  var N=24;

  function normalize(v){
    var mn=Math.min.apply(null,v), mx=Math.max.apply(null,v), d=mx-mn;
    if(d===0) return v.map(function(){return 50;});
    return v.map(function(x){return (x-mn)/d*100;});
  }
  // evenly-spaced y 배열을 N점으로 리샘플
  function resampleY(y,n){
    if(y.length===n) return y.slice();
    var out=[];
    for(var k=0;k<n;k++){
      var t=k/(n-1)*(y.length-1), i=Math.floor(t), f=t-i;
      out.push(i+1<y.length ? y[i]*(1-f)+y[i+1]*f : y[i]);
    }
    return out;
  }
  // [x,y] 폴리라인(x 단조)을 x범위에서 N점 리샘플
  function resamplePath(pts,n){
    var xmin=pts[0][0], xmax=pts[pts.length-1][0], out=[];
    for(var k=0;k<n;k++){
      var tx=xmin+(xmax-xmin)*k/(n-1), j=0;
      while(j<pts.length-2 && pts[j+1][0]<tx) j++;
      var x0=pts[j][0],y0=pts[j][1],x1=pts[j+1][0],y1=pts[j+1][1];
      var f=(x1-x0)?(tx-x0)/(x1-x0):0;
      out.push(y0+(y1-y0)*f);
    }
    return out;
  }
  function pearson(a,b){
    var n=a.length, sa=0,sb=0,saa=0,sbb=0,sab=0;
    for(var i=0;i<n;i++){ sa+=a[i]; sb+=b[i]; saa+=a[i]*a[i]; sbb+=b[i]*b[i]; sab+=a[i]*b[i]; }
    var num=n*sab-sa*sb, den=Math.sqrt((n*saa-sa*sa)*(n*sbb-sb*sb));
    return den===0?0:num/den;
  }

  // 위상 무관 형태 특성 벡터 [추세, 진동량, 수렴, 아치]. 정규화 시리즈에서 추출.
  function features(y){
    y=normalize(y); var n=y.length;
    var net=(y[n-1]-y[0])/100;                     // 추세: -1(하락)~+1(상승)
    var turns=0; for(var i=1;i<n-1;i++){ if((y[i]-y[i-1])*(y[i+1]-y[i])<0) turns++; }
    var osc=turns/(n-2);                            // 진동량: 0~1
    function rng(s){ return Math.max.apply(null,s)-Math.min.apply(null,s); }
    var q=Math.max(2,Math.round(n/3));
    var conv=(rng(y.slice(0,q))-rng(y.slice(n-q)))/100;  // 수렴: >0 좁혀짐
    var arch=[]; for(var i=0;i<n;i++){ var t=i/(n-1); arch.push(-Math.pow((t-0.5)*2,2)); }
    var arc=pearson(y,arch);                        // 아치: +1 상승후하락(산), -1 하락후상승(골)
    return [net,osc,conv,arc];
  }
  function simScore(fi,fp){
    var d=0; for(var i=0;i<fi.length;i++){ var e=fi[i]-fp[i]; d+=e*e; }
    return Math.round(100*Math.max(0,1-Math.sqrt(d)/1.8));
  }

  // 패턴 기준형태 특성 (basePath + 첫 상태 structurePath = 교과서 형태)
  function signature(pattern){
    var s=pattern.structure, first=pattern.stateOrder[0];
    var path=s.basePath.concat((pattern.states[first].structurePath)||[]);
    return features(resamplePath(path,N));
  }

  // 입력 종가 → 특성 벡터
  function seriesVec(closes){ return features(resampleY(closes,N)); }

  // 매칭: match 메타 있는 패턴만 후보. TOP k 반환.
  function matchFlow(closes, patternsById, k){
    k=k||3;
    var input=seriesVec(closes), out=[];
    Object.keys(patternsById).forEach(function(id){
      var p=patternsById[id]; if(!p.match) return;         // 형태 없는 패턴(거래량 등) 제외
      out.push({ id:id, title:p.title, tagColor:p.tagColor,
        score:simScore(input, signature(p)),
        similar:p.match.similar, missing:p.match.missing, misread:p.match.misread });
    });
    out.sort(function(a,b){ return b.score-a.score; });
    return out.slice(0,k);
  }

  function parseCloses(text){
    return String(text||"").split(/[^0-9.\-]+/).map(parseFloat).filter(function(x){return isFinite(x);});
  }

  var API={ N:N, matchFlow:matchFlow, seriesVec:seriesVec, signature:signature, parseCloses:parseCloses, pearson:pearson };
  if(typeof module!=="undefined"&&module.exports) module.exports=API;
  else (root.F29=root.F29||{}).MatchEngine=API;
})(typeof window!=="undefined"?window:this);
