/* F29 Pattern Match — match-engine.js
   입력 가격 흐름을 학습용 패턴의 기준형태와 비교해 유사도(형태 닮음 점수) 나열.
   판독·확정·방향 제시 안 함. 유사도는 확률이 아니다.
   기준형태 = 패턴 basePath + 첫 상태 structurePath (교과서 형태), N점 리샘플 후 0~100 정규화.
   유사도 = 정규화 벡터 간 피어슨 상관 → max(0,r)*100. (스케일·offset 무관, 모양만)
   node/browser 겸용(UMD). */
(function(root){
  var N=24;

  function normalize(v){
    var mn=Math.min.apply(null,v), mx=Math.max.apply(null,v), d=mx-mn;
    if(d===0) return v.map(function(){return 50;});
    return v.map(function(x){return (x-mn)/d*100;});
  }
  // evenly-spaced y 배열을 N점으로 리샘플
  function resampleY(y,n){
    if(y.length===n) return y.slice();
    var out=[];
    for(var k=0;k<n;k++){
      var t=k/(n-1)*(y.length-1), i=Math.floor(t), f=t-i;
      out.push(i+1<y.length ? y[i]*(1-f)+y[i+1]*f : y[i]);
    }
    return out;
  }
  // [x,y] 폴리라인(x 단조)을 x범위에서 N점 리샘플
  function resamplePath(pts,n){
    var xmin=pts[0][0], xmax=pts[pts.length-1][0], out=[];
    for(var k=0;k<n;k++){
      var tx=xmin+(xmax-xmin)*k/(n-1), j=0;
      while(j<pts.length-2 && pts[j+1][0]<tx) j++;
      var x0=pts[j][0],y0=pts[j][1],x1=pts[j+1][0],y1=pts[j+1][1];
      var f=(x1-x0)?(tx-x0)/(x1-x0):0;
      out.push(y0+(y1-y0)*f);
    }
    return out;
  }
  function pearson(a,b){
    var n=a.length, sa=0,sb=0,saa=0,sbb=0,sab=0;
    for(var i=0;i<n;i++){ sa+=a[i]; sb+=b[i]; saa+=a[i]*a[i]; sbb+=b[i]*b[i]; sab+=a[i]*b[i]; }
    var num=n*sab-sa*sb, den=Math.sqrt((n*saa-sa*sa)*(n*sbb-sb*sb));
    return den===0?0:num/den;
  }

  // 위상 무관 형태 특성 벡터 [추세, 진동량, 수렴, 아치]. 정규화 시리즈에서 추출.
  function features(y){
    y=normalize(y); var n=y.length;
    var net=(y[n-1]-y[0])/100;                     // 추세: -1(하락)~+1(상승)
    var turns=0; for(var i=1;i<n-1;i++){ if((y[i]-y[i-1])*(y[i+1]-y[i])<0) turns++; }
    var osc=turns/(n-2);                            // 진동량: 0~1
    function rng(s){ return Math.max.apply(null,s)-Math.min.apply(null,s); }
    var q=Math.max(2,Math.round(n/3));
    var conv=(rng(y.slice(0,q))-rng(y.slice(n-q)))/100;  // 수렴: >0 좁혀짐
    var arch=[]; for(var i=0;i<n;i++){ var t=i/(n-1); arch.push(-Math.pow((t-0.5)*2,2)); }
    var arc=pearson(y,arch);                        // 아치: +1 상승후하락(산), -1 하락후상승(골)
    return [net,osc,conv,arc];
  }
  function simScore(fi,fp){
    var d=0; for(var i=0;i<fi.length;i++){ var e=fi[i]-fp[i]; d+=e*e; }
    return Math.round(100*Math.max(0,1-Math.sqrt(d)/1.8));
  }

  // 패턴 기준형태 특성 (basePath + 첫 상태 structurePath = 교과서 형태)
  function signature(pattern){
    var s=pattern.structure, first=pattern.stateOrder[0];
    var path=s.basePath.concat((pattern.states[first].structurePath)||[]);
    return features(resamplePath(path,N));
  }

  // 입력 종가 → 특성 벡터
  function seriesVec(closes){ return features(resampleY(closes,N)); }

  // 매칭: match 메타 있는 패턴만 후보. TOP k 반환.
  function matchFlow(closes, patternsById, k){
    k=k||3;
    var input=seriesVec(closes), out=[];
    Object.keys(patternsById).forEach(function(id){
      var p=patternsById[id]; if(!p.match) return;         // 형태 없는 패턴(거래량 등) 제외
      out.push({ id:id, title:p.title, tagColor:p.tagColor,
        score:simScore(input, signature(p)),
        similar:p.match.similar, missing:p.match.missing, misread:p.match.misread });
    });
    out.sort(function(a,b){ return b.score-a.score; });
    return out.slice(0,k);
  }

  function parseCloses(text){
    return String(text||"").split(/[^0-9.\-]+/).map(parseFloat).filter(function(x){return isFinite(x);});
  }

  // 인베스팅닷컴 등 OHLCV 표 파서.
  // 반환: {hadTable, closes:[과거→현재], ohlcv:[{date,open,high,low,close,volume}], count}
  // 매칭은 closes 만 사용. ohlcv 는 보존(다음 단계 품질 레이어용).
  function parseVolume(tok){
    if(!tok) return null;
    var m=String(tok).replace(/,/g,"").match(/([\d.]+)\s*([MBKmbk])?/);
    if(!m) return null;
    var v=parseFloat(m[1]); if(!isFinite(v)) return null;
    var u=(m[2]||"").toUpperCase();
    return u==="B"?v*1e9:u==="M"?v*1e6:u==="K"?v*1e3:v;
  }
  function parseDateKey(s){
    var m=String(s).match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/);           // 2026년 07월 02일 / 2026-07-02
    if(m) return (+m[1])*10000+(+m[2])*100+(+m[3]);
    var m2=String(s).match(/(\d{1,2})\D+(\d{1,2})\D+(\d{4})/);          // 07/02/2026
    if(m2) return (+m2[3])*10000+(+m2[1])*100+(+m2[2]);
    return null;
  }
  // 입력 방어 상한
  var MAX_CHARS=20000, MAX_LINES=600, MAX_POINTS=400;
  function sanePrice(x){ return isFinite(x) && x>0 && x<1e7; }   // 음수·0·비현실치 차단

  function parseTable(text){
    var raw=String(text||"");
    var truncated=false;
    if(raw.length>MAX_CHARS){ raw=raw.slice(0,MAX_CHARS); truncated=true; }   // 글자수 상한
    var datesDetected=/(\d{4}\D+\d{1,2}\D+\d{1,2})|(\d{1,2}\D+\d{1,2}\D+\d{4})/.test(raw);
    // 날짜가 하나도 없으면 = 단순 종가 목록 (인베스팅 표 아님)
    if(!datesDetected){
      var cl=parseCloses(raw).filter(sanePrice);
      if(cl.length>MAX_POINTS) cl=cl.slice(-MAX_POINTS);
      return {hadTable:false, datesDetected:false, closes:cl, ohlcv:[], count:0, truncated:truncated};
    }
    var lines=raw.split(/\r?\n/).map(function(l){return l.trim();}).filter(Boolean).slice(0,MAX_LINES);
    var rows=[];
    lines.forEach(function(line){
      var dateKey=parseDateKey(line);
      if(dateKey==null) return;                                       // 날짜 없는 줄(헤더 등) 스킵
      var volTok=(line.match(/[\d,.]+\s*[MBKmbk]\b/)||[])[0];
      var volume=volTok?parseVolume(volTok):null;
      var rest=line.replace(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/,"")
                   .replace(/(\d{1,2})\D+(\d{1,2})\D+(\d{4})/,"")
                   .replace(/[\d,.]+\s*[MBKmbk]\b/,"")
                   .replace(/[+\-]?[\d.]+\s*%/g,"");
      var nums=(rest.match(/-?[\d,]*\.?\d+/g)||[]).map(function(n){return parseFloat(n.replace(/,/g,""));}).filter(sanePrice);
      if(nums.length===0) return;
      if(nums.length>=4){
        var four=nums.slice(0,4);
        rows.push({dateKey:dateKey, close:four[0], open:four[1], high:Math.max.apply(null,four), low:Math.min.apply(null,four), volume:volume});
      }else{
        rows.push({dateKey:dateKey, close:nums[0], open:null, high:null, low:null, volume:volume});
      }
    });
    if(rows.length===0){
      // 날짜는 있는데 가격을 못 뽑음 = 깨진/잘못된 표
      return {hadTable:false, datesDetected:true, closes:[], ohlcv:[], count:0, truncated:truncated};
    }
    var seen={}; rows=rows.filter(function(r){ if(seen[r.dateKey]) return false; seen[r.dateKey]=1; return true; });
    rows.sort(function(a,b){return a.dateKey-b.dateKey;});          // 과거→현재
    if(rows.length>MAX_POINTS) rows=rows.slice(-MAX_POINTS);        // 최근 것만
    var ohlcv=rows.map(function(r){return {date:r.dateKey,open:r.open,high:r.high,low:r.low,close:r.close,volume:r.volume};});
    return {hadTable:true, datesDetected:true, closes:ohlcv.map(function(r){return r.close;}), ohlcv:ohlcv, count:ohlcv.length, truncated:truncated};
  }

  // ── 검증: 사용자가 붙인 티커+OHLCV가 서버 데이터와 맞는지 (오염 방지) ──
  function ymd(s){ if(typeof s==="number") return s; var m=String(s).match(/(\d{4})\D(\d{1,2})\D(\d{1,2})/); return m?(+m[1])*10000+(+m[2])*100+(+m[3]):null; }
  function toDate(y){ return new Date(Math.floor(y/10000), (Math.floor(y/100)%100)-1, y%100); }
  function dayGap(a,b){ return Math.round(Math.abs(toDate(a)-toDate(b))/86400000); }
  // pastedOHLCV: [{date:YYYYMMDD, close}] · server: {dates:[str], closes:[num]}
  function verifyPaste(pastedOHLCV, server){
    if(!server||!Array.isArray(server.dates)||!server.dates.length) return {status:"unverified", reason:"no_server_data"};
    var sv={}; server.dates.forEach(function(d,i){ var k=ymd(d); if(k!=null) sv[k]=server.closes[i]; });
    var diffs=[], overlap=0;
    pastedOHLCV.forEach(function(p){ if(p.date==null) return; var s=sv[p.date]; if(s!=null&&s>0){ overlap++; diffs.push(Math.abs(p.close-s)/s); } });
    if(overlap<5) return {status:"unverified", reason:"low_overlap", overlap:overlap};
    diffs.sort(function(a,b){return a-b;});
    var med=diffs[Math.floor(diffs.length/2)];
    var lp=Math.max.apply(null,pastedOHLCV.map(function(p){return p.date;}));
    var ls=Math.max.apply(null,server.dates.map(ymd));
    var gap=dayGap(lp,ls);
    var ok=(med<=0.005 && gap<=5);            // 종가 차이 중앙값 0.5% 이내 + 최신 5일 이내
    return {status: ok?"verified":"mismatch", overlap:overlap, median:Math.round(med*10000)/100, dayGap:gap};
  }
  // 액면분할·수정주가·오류 의심: 전일 대비 35%+ 갭 개수
  function detectSplits(closes){ var n=0; for(var i=1;i<closes.length;i++){ if(closes[i-1]>0 && Math.abs(closes[i]-closes[i-1])/closes[i-1]>0.35) n++; } return n; }

  var API={ N:N, matchFlow:matchFlow, seriesVec:seriesVec, signature:signature, parseCloses:parseCloses, parseTable:parseTable, verifyPaste:verifyPaste, detectSplits:detectSplits, pearson:pearson };
  if(typeof module!=="undefined"&&module.exports) module.exports=API;
  else (root.F29=root.F29||{}).MatchEngine=API;
})(typeof window!=="undefined"?window:this);
