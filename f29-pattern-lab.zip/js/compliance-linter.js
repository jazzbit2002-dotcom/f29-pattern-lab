/* F29 Pattern Lab — compliance-linter.js
   §8 코드 강제. 2층 구조:
     HARD (빌드 실패): 매매 지시·확률 단정어
     SOFT (경고만, 사람 확인): 톤/오해 소지 표현
   substring 오탐 방지: 안전 복합어는 SAFE_COMPOUNDS로 예외 처리 (예: 진입 ⊂ 재진입).
   node(build.js)와 browser 양쪽에서 사용. */
(function(root){
  var HARD=["매수","매도","목표가","손절가","상승확률","하락확률"];
  var SOFT=["진입","베팅","급등","급락","예상"];
  // 해당 단어를 포함하지만 허용되는 복합어. 스캔 전에 텍스트에서 제거해 오탐을 막는다.
  var SAFE_COMPOUNDS={
    "진입":["재진입"],
    "매수":["매수세"],   // 승인 2026-07-05: 시장상태 설명어. "매수 구간/타이밍"·맨 "매수"는 계속 하드 차단
    "매도":["매도세"]    // 승인 2026-07-05: 동일. "매도벽"·"매도 구간"은 보류(하드 유지)
  };
  function scan(text, words){
    var hits=[];
    words.forEach(function(w){
      var t=String(text||"");
      (SAFE_COMPOUNDS[w]||[]).forEach(function(safe){ t=t.split(safe).join(""); });
      if(t.indexOf(w)>=0) hits.push(w);
    });
    return hits;
  }
  function collectText(pattern){
    var out=[];
    function add(s){ if(typeof s==="string") out.push(s); }
    add(pattern.title); add(pattern.tag); add(pattern.shortDescription); add(pattern.coreLesson);
    (pattern.structure&&pattern.structure.labels||[]).forEach(function(l){ add(l.text); });
    (pattern.structure&&pattern.structure.referenceLines||[]).forEach(function(r){ add(r.label); });
    (pattern.stateOrder||[]).forEach(function(k){
      var st=(pattern.states||{})[k]; if(!st) return;
      add(st.label); add(st.title); add(st.description); add(st.warning);
      (st.conditions||[]).forEach(function(c){ add(c[0]); add(c[1]); });
      if(st.marker) add(st.marker.text);
    });
    if(pattern.match){ add(pattern.match.similar); add(pattern.match.missing); add(pattern.match.misread); }
    (pattern.quiz||[]).forEach(function(q){ add(q.prompt); (q.choices||[]).forEach(add); add(q.explanation); });
    return out.join("  ");
  }
  var Linter={
    HARD:HARD, SOFT:SOFT,
    lintText:function(text){ return {hard:scan(text,HARD), soft:scan(text,SOFT)}; },
    lintPattern:function(pattern){
      var blob=collectText(pattern);
      var h=scan(blob,HARD), s=scan(blob,SOFT);
      // 중복 제거
      var uniq=function(a){return a.filter(function(v,i){return a.indexOf(v)===i;});};
      return {hard:uniq(h), soft:uniq(s)};
    }
  };
  if(typeof module!=="undefined"&&module.exports) module.exports=Linter;
  else (root.F29=root.F29||{}).ComplianceLinter=Linter;
})(typeof window!=="undefined"?window:this);
