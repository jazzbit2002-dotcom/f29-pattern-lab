/* F29 Pattern Lab — tokens.js  (§9 F29 규격. Canvas/SVG용 hex 미러, :root와 동일값) */
(function(root){
  var TOK={bg:"#0A0E17",card:"#131A28",card2:"#0F1520",line:"#1F2A3D",line2:"#2A3850",
    txt:"#E6EDF6",txt2:"#8FA0B8",txt3:"#5C6B84",teal:"#3DD8B0",up:"#3DDC84",down:"#F0997B",gold:"#E0B341"};
  function col(key){ return TOK[key]||key; }   // 토큰키 또는 원시 hex 허용
  var F=(root.F29=root.F29||{}); F.TOK=TOK; F.col=col;
})(window);
