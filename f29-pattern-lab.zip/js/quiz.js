/* F29 Pattern Lab — quiz.js  판독 퀴즈.
   목적: "이 패턴이 무엇인가"가 아니라 "이 상태를 확정으로 봐도 되는가 / 무엇이 부족한가 / 어디서 착각하는가"를 훈련.
   각 패턴 JSON의 quiz 배열을 F29 색깔 순서로 모아 출제. 오답 유형은 localStorage 집계. */
(function(root){
  var F=(root.F29=root.F29||{});
  // F29 색깔 강한 순서 (오판 방지형 우선)
  var ORDER=["fake-breakout","box-breakout","triangle","broadening","rounding-top","head-and-shoulders",
             "support-resistance","trendline","volume","double-top","double-bottom"];
  var LS_KEY="f29quiz_mistakes";

  function bundle(){ return F.PATTERN_BUNDLE||{}; }
  function collect(){
    var out=[], b=bundle();
    ORDER.forEach(function(id){
      var p=b[id]; if(!p||!Array.isArray(p.quiz)) return;
      p.quiz.forEach(function(q){ out.push({q:q, pattern:p}); });
    });
    // ORDER 밖 패턴도 뒤에 (누락 방지)
    Object.keys(b).forEach(function(id){
      if(ORDER.indexOf(id)>=0) return;
      var p=b[id]; if(p&&Array.isArray(p.quiz)) p.quiz.forEach(function(q){ out.push({q:q,pattern:p}); });
    });
    return out;
  }
  function loadMistakes(){ try{ return JSON.parse(localStorage.getItem(LS_KEY))||{}; }catch(e){ return {}; } }
  function saveMistake(type){ try{ var m=loadMistakes(); m[type]=(m[type]||0)+1; localStorage.setItem(LS_KEY,JSON.stringify(m)); }catch(e){} }

  var items=[], idx=0, answered=false, correctCount=0;

  function el(id){ return document.getElementById(id); }

  function renderQuestion(){
    var host=el("quizbody"); if(!host) return;
    var it=items[idx], q=it.q, p=it.pattern;
    answered=false;
    host.innerHTML=
      '<div class="qz-top"><span class="qz-prog">문제 '+(idx+1)+' / '+items.length+'</span>'+
      '<span class="qz-pat">'+p.title+'</span></div>'+
      '<canvas id="qzchart" width="480" height="150"></canvas>'+
      '<div class="qz-prompt">'+q.prompt+'</div>'+
      '<div class="qz-choices" id="qzchoices"></div>'+
      '<div class="qz-feedback" id="qzfb" style="display:none"></div>'+
      '<button class="qz-next" id="qznext" style="display:none">다음 문제</button>';
    // 차트: 해당 상태 캔들 렌더
    try{ F.CandleRenderer.render(el("qzchart"), p, q.stateKey||p.stateOrder[0]); }catch(e){}
    var ch=el("qzchoices");
    q.choices.forEach(function(c,j){
      var b=document.createElement("button");
      b.type="button"; b.className="qz-choice"; b.textContent=c;
      b.addEventListener("click",function(){ pick(j); });
      ch.appendChild(b);
    });
    el("qznext").addEventListener("click",next);
  }

  function pick(j){
    if(answered) return; answered=true;
    var it=items[idx], q=it.q, correct=(j===q.answer);
    if(correct) correctCount++; else saveMistake(q.mistakeType);
    var btns=el("qzchoices").querySelectorAll(".qz-choice");
    btns.forEach(function(b,k){
      b.disabled=true;
      if(k===q.answer) b.classList.add("correct");
      else if(k===j) b.classList.add("wrong");
    });
    var fb=el("qzfb"); fb.style.display="";
    fb.className="qz-feedback "+(correct?"ok":"no");
    fb.innerHTML=
      '<div class="qz-verdict">'+(correct?"정답입니다":"오답입니다")+'</div>'+
      '<div class="qz-exp">'+q.explanation+'</div>'+
      '<div class="qz-mtype">오답 유형 · '+q.mistakeType+'</div>';
    el("qznext").style.display="";
    el("qznext").textContent = (idx+1<items.length)?"다음 문제":"결과 보기";
  }

  function next(){
    if(idx+1<items.length){ idx++; renderQuestion(); }
    else renderResult();
  }

  function renderResult(){
    var host=el("quizbody"); if(!host) return;
    var m=loadMistakes();
    var rows=Object.keys(m).sort(function(a,b){return m[b]-m[a];})
      .map(function(t){ return '<div class="qz-mrow"><span>'+t+'</span><span>'+m[t]+'</span></div>'; }).join("");
    host.innerHTML=
      '<div class="qz-result"><div class="qz-score">'+correctCount+' / '+items.length+'</div>'+
      '<div class="qz-sub">이번 회차 정답</div></div>'+
      '<div class="qz-mtitle">누적 오답 유형 (약점)</div>'+
      '<div class="qz-mlist">'+(rows||'<div class="qz-mrow"><span>아직 오답 없음</span><span></span></div>')+'</div>'+
      '<div class="qz-btns"><button class="qz-next" id="qzretry">다시 풀기</button>'+
      '<button class="qz-exit2" id="qzexit2">패턴으로 돌아가기</button></div>';
    el("qzretry").addEventListener("click",function(){ idx=0; correctCount=0; renderQuestion(); });
    el("qzexit2").addEventListener("click",exit);
  }

  function start(){
    items=collect(); idx=0; correctCount=0;
    var pv=el("patternview"), qv=el("quizview");
    if(items.length===0){ if(qv){ qv.style.display=""; el("quizbody").innerHTML='<div class="qz-empty">아직 퀴즈가 준비된 패턴이 없습니다.</div>'; } return; }
    if(pv) pv.style.display="none";
    if(qv) qv.style.display="";
    renderQuestion();
  }
  function exit(){
    var pv=el("patternview"), qv=el("quizview");
    if(qv) qv.style.display="none";
    if(pv) pv.style.display="";
  }

  F.Quiz={ start:start, exit:exit };
})(window);
