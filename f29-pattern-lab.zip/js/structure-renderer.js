/* F29 Pattern Lab — structure-renderer.js
   pattern.structure + state.structurePath 로 SVG 구조도 렌더. 패턴 전용 로직 없음. */
(function(root){
  var F=(root.F29=root.F29||{}), col=F.col, C=F.Coords;
  F.StructureRenderer={
    render:function(svg,pattern,stateKey){
      var st=pattern.states[stateKey], S=pattern.structure, P=[];
      // 수평 기준선 (지지/저항/넥라인 등)
      (S.referenceLines||[]).forEach(function(rl){
        var y=C.sy(rl.y);
        P.push('<line x1="'+C.sx(3)+'" y1="'+y+'" x2="'+C.sx(88)+'" y2="'+y+'" stroke="'+col("txt3")+'" stroke-width="1.5" stroke-dasharray="5 4"/>');
        if(rl.label) P.push('<text x="'+(C.sx(88)+4)+'" y="'+(y+4)+'" fill="'+col("txt3")+'" font-size="10">'+rl.label+'</text>');
      });
      // 사선 기준선 (추세선·수렴·쐐기·채널). from/to = chart-natural 좌표.
      (S.referenceSegments||[]).forEach(function(seg){
        var x1=C.sx(seg.from[0]),y1=C.sy(seg.from[1]),x2=C.sx(seg.to[0]),y2=C.sy(seg.to[1]);
        var dash=(seg.style==="solid")?"":' stroke-dasharray="5 4"';
        P.push('<line x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'" stroke="'+col(seg.color||"txt3")+'" stroke-width="1.5"'+dash+'/>');
        if(seg.label){
          var mx=(x1+x2)/2,my=(y1+y2)/2;
          P.push('<text x="'+mx+'" y="'+(my-6)+'" fill="'+col(seg.color||"txt3")+'" font-size="10" text-anchor="middle">'+seg.label+'</text>');
        }
      });
      var path=S.basePath.concat(st.structurePath||[]);
      var d="M"+C.sx(path[0][0])+","+C.sy(path[0][1]);
      for(var i=1;i<path.length;i++) d+=" L"+C.sx(path[i][0])+","+C.sy(path[i][1]);
      P.push('<path d="'+d+'" fill="none" stroke="'+col(st.pathColor)+'" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>');
      (S.labels||[]).forEach(function(lb){
        var p=S.points[lb.point]; if(!p) return;
        var c=(lb.tone==="bright")?col("txt"):col("txt2");
        P.push('<circle cx="'+C.sx(p[0])+'" cy="'+C.sy(p[1])+'" r="3.5" fill="'+c+'"/>');
        P.push('<text x="'+C.sx(p[0])+'" y="'+(C.sy(p[1])-8)+'" fill="'+c+'" font-size="10" text-anchor="middle">'+lb.text+'</text>');
      });
      svg.innerHTML=P.join("");
    }
  };
})(window);
