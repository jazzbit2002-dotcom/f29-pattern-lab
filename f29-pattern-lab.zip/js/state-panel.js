/* F29 Pattern Lab — state-panel.js  해설/조건/무효화/경고 렌더. */
(function(root){
  var F=(root.F29=root.F29||{}), col=F.col;
  F.StatePanel={
    render:function(box,pattern,stateKey){
      var st=pattern.states[stateKey];
      var kv=(st.conditions||[]).map(function(p){
        return '<div><span class="k">'+p[0]+'</span><span class="v">'+p[1]+'</span></div>';
      }).join("");
      box.innerHTML=
        '<div class="stitle" style="color:'+col(st.titleColor||"txt")+'">'+st.title+'</div>'+
        '<div class="sdesc">'+st.description+'</div>'+
        '<div class="kv">'+kv+'</div>'+
        (st.warning?'<div class="warn">'+st.warning+'</div>':'');
    }
  };
})(window);
