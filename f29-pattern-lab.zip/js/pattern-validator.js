/* F29 Pattern Lab — pattern-validator.js
   패턴 JSON 스키마 검증. errors 있으면 빌드 실패. warnings는 통과하되 보고.
   node(build.js)와 browser 양쪽에서 사용. compliance-linter를 물어 금지어 검사 포함. */
(function(root){
  function isNum(v){ return typeof v==="number" && isFinite(v); }
  function inRange(v){ return isNum(v) && v>=0 && v<=100; }
  function isPointArr(p){ return Array.isArray(p) && p.length===2 && inRange(p[0]) && inRange(p[1]); }

  function getLinter(){
    if(typeof module!=="undefined"&&module.exports) return require("./compliance-linter.js");
    return (root.F29||{}).ComplianceLinter;
  }

  function validate(pattern){
    var E=[], W=[];
    var id=(pattern&&pattern.id)||"(id 없음)";
    function err(m){ E.push(id+": "+m); }
    function warn(m){ W.push(id+": "+m); }

    if(!pattern||typeof pattern!=="object"){ return {errors:["패턴이 객체가 아님"], warnings:[]}; }

    // 1) 필수 top-level 필드
    ["schemaVersion","renderVersion","order","id","level","category","title","tag","structure","states","stateOrder"]
      .forEach(function(f){ if(pattern[f]===undefined||pattern[f]===null) err("필수 필드 누락: "+f); });
    // order: 정수 0 이상 (커리큘럼 정렬 키)
    if(pattern.order!==undefined&&pattern.order!==null&&(!Number.isInteger(pattern.order)||pattern.order<0))
      err("order 는 0 이상 정수여야 함 (현재: "+pattern.order+")");

    // 2) structure
    var S=pattern.structure;
    if(S && typeof S==="object"){
      if(!Array.isArray(S.basePath)||S.basePath.length<2) err("structure.basePath 는 2개 이상의 좌표 배열이어야 함");
      else S.basePath.forEach(function(p,i){ if(!isPointArr(p)) err("basePath["+i+"] 좌표가 0~100 범위 밖 또는 형식 오류"); });
      if(S.points && typeof S.points==="object"){
        Object.keys(S.points).forEach(function(k){ if(!isPointArr(S.points[k])) err("points."+k+" 좌표가 0~100 범위 밖 또는 형식 오류"); });
      }
      (S.labels||[]).forEach(function(l,i){
        if(!l.point) err("labels["+i+"].point 누락");
        else if(!S.points||!S.points[l.point]) err("labels["+i+"].point='"+l.point+"' 가 points 에 없음");
        if(!l.text) warn("labels["+i+"].text 비어있음");
      });
      (S.referenceLines||[]).forEach(function(r,i){ if(!inRange(r.y)) err("referenceLines["+i+"].y 가 0~100 범위 밖"); });
      // 사선 기준선 (추세선·수렴·쐐기·채널)
      if(S.referenceSegments!==undefined){
        if(!Array.isArray(S.referenceSegments)) err("referenceSegments 가 배열이 아님");
        else S.referenceSegments.forEach(function(seg,i){
          if(!isPointArr(seg.from)) err("referenceSegments["+i+"].from 이 [x,y] 0~100 이 아님");
          if(!isPointArr(seg.to)) err("referenceSegments["+i+"].to 가 [x,y] 0~100 이 아님");
          // label/style/color 는 선택
        });
      }
    } else err("structure 객체 누락");

    // 2b) candleReference: 단일 또는 배열. 각 항목 수평{level} 또는 사선{from:[index,price],to:[index,price]}
    //     ※ from/to 는 정규화 좌표가 아니다. [0]=캔들 index, [1]=실제 가격.
    var CR=pattern.candleReference;
    if(CR){
      var lens=[];
      (pattern.stateOrder||[]).forEach(function(k){ var s=(pattern.states||{})[k]; if(s&&Array.isArray(s.candles)) lens.push(s.candles.length); });
      var minLen=lens.length?Math.min.apply(null,lens):0;
      var crArr=Array.isArray(CR)?CR:[CR];
      crArr.forEach(function(c,ci){
        var hasLevel=isNum(c.level), hasSeg=Array.isArray(c.from)&&Array.isArray(c.to);
        if(!hasLevel&&!hasSeg) err("candleReference["+ci+"] 는 {level} 또는 {from,to} 중 하나여야 함");
        if(hasSeg){
          function chkAnchor(name,a){
            if(!(a.length===2&&isNum(a[0])&&isNum(a[1]))){ err("candleReference["+ci+"]."+name+" 은 [캔들index, 가격] 숫자 2개여야 함"); return; }
            if(a[0]<0||a[0]>minLen-1) err("candleReference["+ci+"]."+name+"[0](캔들index="+a[0]+")가 candles 범위(0~"+(minLen-1)+") 밖");
          }
          chkAnchor("from",c.from); chkAnchor("to",c.to);
        }
      });
    }

    // 3) stateOrder ↔ states 정합
    var order=Array.isArray(pattern.stateOrder)?pattern.stateOrder:[];
    var states=pattern.states||{};
    order.forEach(function(k){ if(!states[k]) err("stateOrder 의 '"+k+"' 가 states 에 없음"); });
    Object.keys(states).forEach(function(k){ if(order.indexOf(k)<0) warn("states 의 '"+k+"' 가 stateOrder 에 없음(렌더 안 됨)"); });

    // 4) 각 state
    order.forEach(function(k){
      var st=states[k]; if(!st) return;
      ["label","title","description","candles"].forEach(function(f){ if(st[f]===undefined||st[f]===null) err("state '"+k+"' 필수 필드 누락: "+f); });

      // candles: 각 [o,h,l,c] 4개 숫자
      if(!Array.isArray(st.candles)||st.candles.length===0) err("state '"+k+"'.candles 가 비어있음");
      else st.candles.forEach(function(c,i){
        if(!Array.isArray(c)||c.length!==4||!c.every(isNum)) err("state '"+k+"'.candles["+i+"] 는 [o,h,l,c] 숫자 4개여야 함");
      });

      // structurePath 좌표 0~100
      (st.structurePath||[]).forEach(function(p,i){ if(!isPointArr(p)) err("state '"+k+"'.structurePath["+i+"] 좌표가 0~100 밖 또는 형식 오류"); });

      // volume(선택): 길이 == candles, 숫자 >=0
      if(st.volume!==undefined){
        if(!Array.isArray(st.volume)) err("state '"+k+"'.volume 이 배열이 아님");
        else{
          if(Array.isArray(st.candles) && st.volume.length!==st.candles.length)
            err("state '"+k+"'.volume 길이("+st.volume.length+")가 candles 길이("+st.candles.length+")와 불일치");
          st.volume.forEach(function(v,i){ if(!isNum(v)||v<0) err("state '"+k+"'.volume["+i+"] 는 0 이상 숫자여야 함"); });
        }
      }

      // marker(선택): atIndex 범위
      if(st.marker){
        var n=Array.isArray(st.candles)?st.candles.length:0;
        if(!Number.isInteger(st.marker.atIndex)||st.marker.atIndex<0||st.marker.atIndex>=n)
          err("state '"+k+"'.marker.atIndex("+st.marker.atIndex+")가 candle 범위(0~"+(n-1)+") 밖");
      }
    });

    // 5) 금지어 (compliance-linter)
    var L=getLinter();
    if(L){
      var lint=L.lintPattern(pattern);
      lint.hard.forEach(function(w){ err("컴플라이언스 하드 금지어: '"+w+"'"); });
      lint.soft.forEach(function(w){ warn("컴플라이언스 주의어: '"+w+"' (사람 확인 필요)"); });
    } else warn("compliance-linter 미로딩 — 금지어 검사 생략");

    // 6) quiz(선택): 스키마 검증
    var MISTAKE_TYPES=["확정 전 착각","거래량 무시","상위봉 무시","무효화 미확인","모양 과신","안착 미확인","변동성 오해"];
    if(pattern.quiz!==undefined){
      if(!Array.isArray(pattern.quiz)) err("quiz 는 배열이어야 함");
      else pattern.quiz.forEach(function(q,i){
        var qi="quiz["+i+"]";
        if(!q||typeof q!=="object"){ err(qi+" 가 객체가 아님"); return; }
        if(typeof q.id!=="string"||!q.id) err(qi+".id 필요(문자열)");
        if(q.stateKey!==undefined && !(pattern.states||{})[q.stateKey]) err(qi+".stateKey '"+q.stateKey+"' 가 states 에 없음");
        if(q.type!=="single-choice") err(qi+".type 는 'single-choice'(v0)");
        if(typeof q.prompt!=="string"||!q.prompt) err(qi+".prompt 필요");
        if(!Array.isArray(q.choices)||q.choices.length<3||q.choices.length>4) err(qi+".choices 는 3~4개");
        else q.choices.forEach(function(c,j){ if(typeof c!=="string"||!c) err(qi+".choices["+j+"] 는 비어있지 않은 문자열"); });
        if(!Number.isInteger(q.answer)||q.answer<0||(Array.isArray(q.choices)&&q.answer>=q.choices.length)) err(qi+".answer 는 choices 범위 인덱스");
        if(typeof q.explanation!=="string"||!q.explanation) err(qi+".explanation 필요");
        if(MISTAKE_TYPES.indexOf(q.mistakeType)<0) err(qi+".mistakeType 는 7유형 중 하나(현재:'"+q.mistakeType+"')");
      });
    }

    return {errors:E, warnings:W};
  }

  var Validator={ validate:validate };
  if(typeof module!=="undefined"&&module.exports) module.exports=Validator;
  else (root.F29=root.F29||{}).PatternValidator=Validator;
})(typeof window!=="undefined"?window:this);
