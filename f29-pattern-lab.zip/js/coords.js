/* F29 Pattern Lab — coords.js
   chart-natural(0~100, y-up) → SVG 뷰박스(y-down) 변환. 모든 구조도 좌표의 단일 규약. */
(function(root){
  var W=480,H=200,PX=20,PY=18;
  function sx(x){ return PX+(W-2*PX)*(x/100); }
  function sy(y){ return PY+(H-2*PY)*(1-y/100); }
  var F=(root.F29=root.F29||{}); F.Coords={W:W,H:H,PX:PX,PY:PY,sx:sx,sy:sy};
})(window);
