/* F29 Pattern Lab — level-bar.js  커리큘럼 난이도 표시(현재 패턴 레벨 강조). */
(function(root){
  var F=(root.F29=root.F29||{});
  var LEVELS=[["intro","입문"],["beginner","초급"],["intermediate","중급"],["advanced","고급"],["quiz","실전 퀴즈"]];
  F.LevelBar={
    render:function(el,level){
      el.innerHTML=LEVELS.map(function(L){
        var on=(L[0]===level)?" on":"";
        if(L[0]==="quiz") return '<button type="button" class="level qzbtn" data-quiz="1">'+L[1]+'</button>';
        return '<span class="'+("level"+on).trim()+'"'+(on?' aria-current="true"':'')+'>'+L[1]+'</span>';
      }).join("");
      var qb=el.querySelector(".qzbtn");
      if(qb) qb.addEventListener("click",function(){ if(F.Quiz) F.Quiz.start(); });
    }
  };
})(window);
