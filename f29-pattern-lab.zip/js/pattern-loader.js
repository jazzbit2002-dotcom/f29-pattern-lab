/* F29 Pattern Lab — pattern-loader.js
   fetch 우선(프로덕션), 실패 시 자동생성 번들(F29.PATTERN_BUNDLE)로 폴백(file:// 미리보기).
   ※ 번들은 build.js 가 JSON 에서 자동 생성 → 손으로 수정하지 않음(드리프트 없음). */
(function(root){
  var F=(root.F29=root.F29||{});
  var cache={};
  F.PatternLoader={
    manifest:function(){ return F.PATTERN_MANIFEST||[]; },
    load:async function(id){
      if(cache[id]) return cache[id];
      try{
        var res=await fetch("data/patterns/"+id+".json",{cache:"no-store"});
        if(!res.ok) throw new Error("http "+res.status);
        cache[id]=await res.json(); return cache[id];
      }catch(e){
        var b=(F.PATTERN_BUNDLE||{})[id];
        if(b){ cache[id]=b; return b; }
        throw e;
      }
    }
  };
})(window);
