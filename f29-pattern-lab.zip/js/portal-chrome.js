/* F29 Pattern Lab — portal-chrome.js
   포털과 일관된 헤더(로고+언어토글)·푸터의 i18n. 크롬 텍스트만 4개 국어(본문 한국어).
   [data-l]=텍스트 채움, [data-lang]=버튼 토글, [data-mail]=이메일 런타임 조립(스팸방지).
   언어 우선순위: localStorage('f29lang') > 브라우저 언어 > ko. */
(function(){
  // GA4 이벤트 헬퍼 (전역). gtag 미로드·광고차단·네트워크 실패에도 앱이 깨지지 않음.
  window.F29track=function(eventName, params){
    try{ if(typeof window.gtag!=="function") return; window.gtag("event", eventName, params||{}); }
    catch(e){ /* tracking must never break the app */ }
  };
  var L={
    ko:{nv1:"미국주식 돈의 흐름",nv2:"비트코인 위험지수",nv3:"투자 플레이북",nv4:"차트 패턴 학습",contact:"문의 및 제안"},
    en:{nv1:"Money Flow",nv2:"Risk Index",nv3:"Investment Playbook",nv4:"Pattern Lab",contact:"Contact"},
    zh:{nv1:"资金流向",nv2:"风险指数",nv3:"投资操作手册",nv4:"图表形态学习",contact:"联系"},
    ja:{nv1:"資金の流れ",nv2:"リスク指数",nv3:"投資プレイブック",nv4:"チャートパターン学習",contact:"お問い合わせ"}
  };
  function detect(){
    try{ var s=localStorage.getItem("f29lang"); if(s&&L[s]) return s; }catch(e){}
    var n=(navigator.language||"ko").slice(0,2).toLowerCase();
    return L[n]?n:"ko";
  }
  function setLang(lang){
    if(!L[lang]) lang="ko";
    try{ localStorage.setItem("f29lang",lang); }catch(e){}
    document.documentElement.lang=lang;
    var d=L[lang];
    document.querySelectorAll("[data-l]").forEach(function(el){ var k=el.getAttribute("data-l"); if(d[k]!=null) el.textContent=d[k]; });
    document.querySelectorAll("[data-lang]").forEach(function(b){ b.classList.toggle("on", b.getAttribute("data-lang")===lang); });
  }
  function init(){
    document.querySelectorAll("[data-lang]").forEach(function(b){
      b.addEventListener("click",function(){ setLang(b.getAttribute("data-lang")); });
    });
    var u="admin",dm="f29";
    document.querySelectorAll("[data-mail]").forEach(function(el){ el.textContent=u+String.fromCharCode(64)+dm+".io"; });
    setLang(detect());
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",init); else init();
})();
