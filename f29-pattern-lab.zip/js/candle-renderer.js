/* F29 Pattern Lab — candle-renderer.js
   state.candles(고정 [o,h,l,c]) 로 Canvas 캔들 렌더.
   candleReference: {level}=수평 / {from:[idx,price],to:[idx,price]}=사선(추세선).
   volume(선택): state.volume 있으면 캔들 아래 볼륨 막대. 없으면 기존처럼 캔들만(기존 패턴 무손상).
   레이아웃(볼륨 있을 때): 캔들 72% + 간격 5px + 볼륨 ~23%. 가격 스케일·기준선은 캔들 영역 안으로 매핑. */
(function(root){
  var F=(root.F29=root.F29||{}), col=F.col;
  F.CandleRenderer={
    render:function(cv,pattern,stateKey){
      var st=pattern.states[stateKey];
      var ctx=cv.getContext("2d"),W=cv.width,H=cv.height,pad=14;
      ctx.clearRect(0,0,W,H);
      var data=st.candles;
      var hasVol=Array.isArray(st.volume)&&st.volume.length===data.length;

      // 영역 분할
      var plotH=H-2*pad, gap=5;
      var candleH=hasVol?plotH*0.72:plotH;
      var volH=hasVol?(plotH-candleH-gap):0;
      var candleTop=pad, candleBot=pad+candleH;
      var volBot=H-pad;                 // 볼륨 막대 바닥

      // 가격 스케일 (캔들 영역 안)
      var vals=[]; data.forEach(function(d){ vals.push(d[1],d[2]); });
      var mn=Math.min.apply(null,vals),mx=Math.max.apply(null,vals);
      var y=function(v){ return candleTop+candleH*(1-(v-mn)/(mx-mn)); };
      var n=data.length,cw=(W-2*pad)/n,cx=function(i){ return pad+cw*i+cw/2; };

      // 기준선: 단일 객체 또는 배열. 수평{level} / 사선{from,to}. refYat=첫 기준선(마커 belowReference용).
      var refYat=null, cr=pattern.candleReference;
      var crList=cr?(Array.isArray(cr)?cr:[cr]):[];
      crList.forEach(function(c){
        if(c.from&&c.to){
          var i1=c.from[0],p1=c.from[1],i2=c.to[0],p2=c.to[1];
          var slope=(p2-p1)/(i2-i1);
          var priceAt=function(idx){ return p1+slope*(idx-i1); };
          if(!refYat) refYat=function(idx){ return y(priceAt(idx)); };
          ctx.strokeStyle=col("txt3"); ctx.setLineDash([5,4]); ctx.lineWidth=1;
          // 앵커 사이 세그먼트로 한정 (수렴선이 apex 넘어 교차하지 않게)
          ctx.beginPath(); ctx.moveTo(cx(i1),y(p1)); ctx.lineTo(cx(i2),y(p2)); ctx.stroke(); ctx.setLineDash([]);
        }else if(c.level!=null){
          var ry=y(c.level); if(!refYat) refYat=function(){ return ry; };
          ctx.strokeStyle=col("txt3"); ctx.setLineDash([5,4]); ctx.lineWidth=1;
          ctx.beginPath(); ctx.moveTo(pad,ry); ctx.lineTo(W-pad,ry); ctx.stroke(); ctx.setLineDash([]);
        }
      });

      // 캔들 (캔들 영역)
      data.forEach(function(d,i){
        var o=d[0],h=d[1],l=d[2],c=d[3],x=cx(i),up=c>=o,cc=up?col("up"):col("down");
        ctx.strokeStyle=cc; ctx.fillStyle=cc; ctx.lineWidth=1;
        ctx.beginPath(); ctx.moveTo(x,y(h)); ctx.lineTo(x,y(l)); ctx.stroke();
        var bw=Math.max(cw*0.6,2),yo=y(o),yc=y(c);
        ctx.fillRect(x-bw/2,Math.min(yo,yc),bw,Math.max(Math.abs(yc-yo),1));
      });

      // 볼륨 막대 (볼륨 영역) — 캔들과 같은 up/down 색, 반투명으로 캔들 우선
      if(hasVol){
        var vmax=Math.max.apply(null,st.volume)||1;
        ctx.globalAlpha=0.6;
        st.volume.forEach(function(vv,i){
          var barH=Math.max(volH*(vv/vmax),1),x=cx(i);
          var up=data[i][3]>=data[i][0];
          ctx.fillStyle=up?col("up"):col("down");
          var bw=Math.max(cw*0.6,2);
          ctx.fillRect(x-bw/2, volBot-barH, bw, barH);
        });
        ctx.globalAlpha=1;
      }

      // 마커 (캔들 영역 기준)
      if(st.marker){
        var m=st.marker,mxp=cx(m.atIndex);
        var my=(m.placement==="belowReference"&&refYat)?refYat(m.atIndex)+16:y(mn)+2;
        ctx.fillStyle=col(m.color||"down"); ctx.font="10px sans-serif"; ctx.textAlign="center";
        ctx.fillText(m.text,mxp,my);
      }
    }
  };
})(window);
