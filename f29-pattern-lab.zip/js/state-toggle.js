/* F29 Pattern Lab — state-toggle.js  stateOrder 로 상태 버튼 자동 생성(가변 개수). */
(function(root){
  var F=(root.F29=root.F29||{});
  F.StateToggle={
    build:function(container,pattern,onSelect){
      container.innerHTML="";
      pattern.stateOrder.forEach(function(key,idx){
        var b=document.createElement("button");
        b.type="button"; b.textContent=pattern.states[key].label; b.dataset.s=key;
        if(idx===0) b.className="on";
        b.addEventListener("click",function(){ onSelect(key); });
        container.appendChild(b);
      });
    },
    setActive:function(container,stateKey){
      container.querySelectorAll("button").forEach(function(b){ b.classList.toggle("on",b.dataset.s===stateKey); });
    }
  };
})(window);
