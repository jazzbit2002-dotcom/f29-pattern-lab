/* F29 Pattern Lab — pattern-engine.js
   오케스트레이터. 어떤 패턴(schemaVersion pattern-v1)이든 4개 렌더러로 그린다. */
(function(root){
  var F=(root.F29=root.F29||{}), col=F.col;
  F.PatternEngine={
    pattern:null, els:{},
    _resolve:function(){
      this.els={
        struct:document.getElementById("struct"),
        candles:document.getElementById("candles"),
        readout:document.getElementById("readout"),
        states:document.getElementById("states"),
        patname:document.getElementById("patname"),
        patdesc:document.getElementById("patdesc"),
        levelbar:document.getElementById("levelbar"),
        cbanner:document.getElementById("cbanner"),
        volcap:document.getElementById("volcap")
      };
    },
    mount:function(pattern){
      this.pattern=pattern; this._resolve();
      // 볼륨 캡션: 이 패턴이 volume 을 쓸 때만 표시
      var usesVol=pattern.stateOrder.some(function(k){ var s=pattern.states[k]; return Array.isArray(s.volume)&&s.volume.length; });
      if(this.els.volcap) this.els.volcap.style.display=usesVol?"":"none";
      // 런타임 컴플라이언스 스캔 (§8 코드 강제 · linter 재사용)
      this.els.cbanner.style.display="none"; this.els.cbanner.textContent="";
      var L=F.ComplianceLinter;
      if(L){
        var lint=L.lintPattern(pattern);
        if(lint.hard.length){
          console.error("[F29 Compliance] 하드 금지어:",lint.hard,"→",pattern.id);
          this.els.cbanner.style.display="block";
          this.els.cbanner.textContent="컴플라이언스 차단 · 하드 금지어: "+lint.hard.join(", ");
        }else if(lint.soft.length){
          console.warn("[F29 Compliance] 주의어:",lint.soft,"→",pattern.id);
        }
      }
      this.els.patname.innerHTML=pattern.title+' <span class="pattag" style="color:'+col(pattern.tagColor||"down")+';background:#2A1A17">'+pattern.tag+'</span>';
      this.els.patdesc.textContent=pattern.shortDescription+" "+pattern.coreLesson;
      F.LevelBar.render(this.els.levelbar,pattern.level);
      window.F29track&&window.F29track("pattern_view",{pattern_id:pattern.id,pattern_title:pattern.title,pattern_level:pattern.level,pattern_category:pattern.category});
      var self=this;
      F.StateToggle.build(this.els.states,pattern,function(k){
        window.F29track&&window.F29track("pattern_state_click",{pattern_id:pattern.id,state_key:k});
        self.show(k);
      });
      this.show(pattern.stateOrder[0]);
    },
    show:function(stateKey){
      var p=this.pattern;
      F.StructureRenderer.render(this.els.struct,p,stateKey);
      F.CandleRenderer.render(this.els.candles,p,stateKey);
      F.StatePanel.render(this.els.readout,p,stateKey);
      F.StateToggle.setActive(this.els.states,stateKey);
    }
  };
})(window);
